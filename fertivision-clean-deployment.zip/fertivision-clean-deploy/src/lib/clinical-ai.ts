// Advanced AI Clinical Decision Support System for Reproductive Medicine

export interface PatientMedicalHistory {
  previousCycles: {
    cycleNumber: number;
    protocol: string;
    stimulationDuration: number;
    totalGonadotropinDose: number;
    peakE2: number;
    oocytesRetrieved: number;
    matureOocytes: number;
    fertilizationRate: number;
    blastocystRate: number;
    outcome: 'pregnant' | 'not_pregnant' | 'cancelled';
    complications?: string[];
  }[];
  diagnoses: {
    primary: 'male_factor' | 'tubal_factor' | 'ovulatory_dysfunction' | 'endometriosis' | 'unexplained' | 'diminished_ovarian_reserve' | 'uterine_factor';
    secondary?: string[];
    severity: 'mild' | 'moderate' | 'severe';
  };
  medications: {
    name: string;
    dosage: string;
    duration: string;
    response?: 'good' | 'poor' | 'hyper';
  }[];
  allergies: string[];
  surgicalHistory: {
    procedure: string;
    date: string;
    outcome: string;
  }[];
}

export interface CurrentTestResults {
  hormones: {
    AMH: number; // ng/ml
    FSH: number; // IU/L
    LH: number; // IU/L
    E2: number; // pg/ml
    TSH: number; // mIU/L
    prolactin: number; // ng/ml
    testosterone?: number; // ng/dl
    DHEAS?: number; // μg/dl
  };
  ultrasound: {
    antrallFollicleCount: number;
    ovarianVolume: { left: number; right: number };
    endometrialThickness: number;
    uterineAbnormalities?: string[];
    ovarian_cysts?: {
      size: number;
      type: string;
      location: 'left' | 'right';
    }[];
  };
  genetics?: {
    karyotype?: string;
    carrierScreening?: { gene: string; status: 'carrier' | 'affected' | 'normal' }[];
    pgtResults?: { embryoId: string; result: 'normal' | 'abnormal'; details: string }[];
  };
}

export interface PatientDemographics {
  age: number;
  BMI: number;
  ethnicity: string;
  lifestyle: {
    smoking: 'never' | 'former' | 'current';
    alcohol: 'none' | 'occasional' | 'moderate' | 'heavy';
    exercise: 'sedentary' | 'light' | 'moderate' | 'vigorous';
    stress_level: 1 | 2 | 3 | 4 | 5;
  };
  occupation?: string;
  insurance?: {
    coverage: 'full' | 'partial' | 'none';
    cycleLimit?: number;
  };
}

export interface TreatmentRecommendation {
  protocol: {
    type: 'antagonist' | 'long_agonist' | 'short_agonist' | 'minimal_stimulation' | 'natural_cycle';
    rationale: string;
    confidence: number; // 0-1
  };
  medications: {
    gonadotropins: {
      type: 'rFSH' | 'hMG' | 'combination';
      startingDose: number; // IU
      adjustmentStrategy: string;
    };
    antagonist?: {
      type: 'cetrorelix' | 'ganirelix';
      startDay: number;
    };
    trigger: {
      type: 'hCG' | 'GnRH_agonist' | 'dual_trigger';
      timing: string;
    };
    lutealSupport: {
      type: 'progesterone' | 'hCG' | 'combination';
      route: 'vaginal' | 'intramuscular' | 'oral';
      duration: string;
    };
  };
  monitoring: {
    baselineAssessment: string[];
    followUpSchedule: {
      day: number;
      tests: string[];
      ultrasound: boolean;
    }[];
    cancelationCriteria: string[];
  };
  predictions: {
    successProbability: {
      clinicalPregnancy: number;
      liveBirth: number;
      confidence: number;
    };
    expectedOutcomes: {
      oocytesRetrieved: { min: number; max: number; expected: number };
      matureOocytes: { min: number; max: number; expected: number };
      blastocysts: { min: number; max: number; expected: number };
    };
    risks: {
      OHSS: { probability: number; severity: 'mild' | 'moderate' | 'severe' };
      multiplePregnancy: number;
      cancellation: number;
    };
  };
  alternatives: {
    protocol: string;
    rationale: string;
    confidence: number;
  }[];
  warnings: string[];
  evidenceLevel: 'A' | 'B' | 'C' | 'D';
  lastUpdated: string;
}

export interface StimulationProtocol {
  protocol: {
    name: string;
    type: 'antagonist' | 'long_agonist' | 'short_agonist' | 'minimal_stimulation';
    duration: number; // days
    confidence: number;
  };
  medications: {
    gonadotropins: {
      medication: string;
      startingDose: number;
      maxDose: number;
      adjustmentCriteria: {
        increase: string[];
        decrease: string[];
        maintain: string[];
      };
    };
    suppression?: {
      medication: string;
      startDay: number;
      duration: string;
    };
    trigger: {
      medication: string;
      criteria: string[];
      timing: string;
    };
  };
  monitoring: {
    baseline: {
      day: number;
      requirements: string[];
    };
    stimulation: {
      day: number;
      tests: string[];
      adjustmentCriteria: string[];
    }[];
    trigger: {
      criteria: string[];
      contraindications: string[];
    };
  };
  predictions: {
    stimulationDuration: { min: number; max: number; expected: number };
    totalGonadotropinDose: { min: number; max: number; expected: number };
    peakE2: { min: number; max: number; expected: number };
    follicleResponse: {
      small: number; // <14mm
      medium: number; // 14-17mm
      large: number; // >17mm
    };
    oocyteYield: { min: number; max: number; expected: number };
    responseCategory: 'poor' | 'normal' | 'high' | 'hyper';
  };
  riskAssessment: {
    OHSS: {
      risk: 'low' | 'moderate' | 'high';
      probability: number;
      preventionMeasures: string[];
    };
    poorResponse: {
      risk: 'low' | 'moderate' | 'high';
      probability: number;
      contingencyPlan: string[];
    };
    cancellation: {
      probability: number;
      criteria: string[];
    };
  };
  alternatives: {
    name: string;
    indication: string;
    confidence: number;
  }[];
  contraindications: string[];
  specialConsiderations: string[];
}

export interface OutcomePrediction {
  embryoAssessment: {
    quality: {
      grade: string;
      morphologyScore: number;
      developmentalPotential: 'excellent' | 'good' | 'fair' | 'poor';
      confidence: number;
    };
    genetics?: {
      ploidy: 'euploid' | 'aneuploid' | 'mosaic' | 'unknown';
      specificAbnormalities?: string[];
      confidence: number;
    };
    timelapseParameters?: {
      cleavageTimings: number[];
      morphokineticScore: number;
      deselectionMarkers: string[];
    };
  }[];
  transferStrategy: {
    recommended: {
      embryoSelection: string;
      numberOfEmbryos: number;
      transferDay: 3 | 5 | 6;
      rationale: string;
      confidence: number;
    };
    alternatives: {
      strategy: string;
      indication: string;
      confidence: number;
    }[];
  };
  predictions: {
    implantation: {
      probability: number;
      confidence: number;
      factors: { factor: string; impact: number }[];
    };
    clinicalPregnancy: {
      probability: number;
      confidence: number;
      gestationalAge: number;
    };
    liveBirth: {
      probability: number;
      confidence: number;
      estimatedDueDate?: string;
    };
    multiplePregnancy: {
      probability: number;
      type: 'twins' | 'triplets';
      risks: string[];
    };
    complications: {
      miscarriage: number;
      ectopicPregnancy: number;
      preterm: number;
      birthDefects: number;
    };
  };
  endometrialReceptivity: {
    assessment: 'optimal' | 'suboptimal' | 'poor';
    thickness: number;
    pattern: string;
    bloodFlow: 'adequate' | 'reduced';
    recommendations: string[];
  };
  recommendations: {
    immediate: string[];
    followUp: string[];
    lifestyle: string[];
    supplements: string[];
  };
  riskFactors: {
    maternal: string[];
    fetal: string[];
    pregnancy: string[];
  };
  evidenceBase: {
    studies: string[];
    sampleSize: number;
    evidenceLevel: 'A' | 'B' | 'C' | 'D';
  };
  followUpPlan: {
    betaHCG: { day: number; expectedRange: { min: number; max: number } }[];
    ultrasound: { week: number; expectedFindings: string[] }[];
    monitoring: string[];
  };
}

// AI Model Simulation Functions
export class ClinicalAI {
  static async generateTreatmentPlan(
    medicalHistory: PatientMedicalHistory,
    testResults: CurrentTestResults,
    demographics: PatientDemographics
  ): Promise<TreatmentRecommendation> {
    // Simulate advanced AI analysis
    const ageScore = this.calculateAgeScore(demographics.age);
    const ovarianReserveScore = this.calculateOvarianReserveScore(testResults.hormones.AMH, testResults.ultrasound.antrallFollicleCount);
    const responseScore = this.calculateResponseScore(medicalHistory.previousCycles);
    
    const protocolType = this.selectOptimalProtocol(ageScore, ovarianReserveScore, responseScore, medicalHistory.diagnoses);
    const successProbability = this.calculateSuccessProbability(ageScore, ovarianReserveScore, demographics.BMI, medicalHistory.diagnoses);
    
    return {
      protocol: {
        type: protocolType,
        rationale: this.generateProtocolRationale(protocolType, ageScore, ovarianReserveScore),
        confidence: 0.85 + Math.random() * 0.1
      },
      medications: this.generateMedicationPlan(protocolType, testResults, demographics),
      monitoring: this.generateMonitoringPlan(protocolType),
      predictions: {
        successProbability: {
          clinicalPregnancy: successProbability.clinical,
          liveBirth: successProbability.liveBirth,
          confidence: 0.82
        },
        expectedOutcomes: this.predictOutcomes(ovarianReserveScore, demographics.age),
        risks: this.assessRisks(demographics, testResults, medicalHistory)
      },
      alternatives: this.generateAlternatives(protocolType),
      warnings: this.generateWarnings(medicalHistory, testResults, demographics),
      evidenceLevel: 'A',
      lastUpdated: new Date().toISOString()
    };
  }

  private static calculateAgeScore(age: number): number {
    if (age < 30) return 1.0;
    if (age < 35) return 0.9;
    if (age < 38) return 0.7;
    if (age < 40) return 0.5;
    if (age < 42) return 0.3;
    return 0.1;
  }

  private static calculateOvarianReserveScore(AMH: number, AFC: number): number {
    const amhScore = AMH > 2.0 ? 1.0 : AMH > 1.0 ? 0.7 : AMH > 0.5 ? 0.4 : 0.1;
    const afcScore = AFC > 15 ? 1.0 : AFC > 10 ? 0.7 : AFC > 5 ? 0.4 : 0.1;
    return (amhScore + afcScore) / 2;
  }

  private static calculateResponseScore(previousCycles: any[]): number {
    if (previousCycles.length === 0) return 0.5;
    const avgOocytes = previousCycles.reduce((sum, cycle) => sum + cycle.oocytesRetrieved, 0) / previousCycles.length;
    return avgOocytes > 15 ? 1.0 : avgOocytes > 10 ? 0.7 : avgOocytes > 5 ? 0.4 : 0.1;
  }

  private static selectOptimalProtocol(ageScore: number, ovarianReserveScore: number, responseScore: number, diagnoses: any): any {
    if (ovarianReserveScore > 0.7) return 'antagonist';
    if (ovarianReserveScore < 0.3) return 'minimal_stimulation';
    if (diagnoses.primary === 'endometriosis') return 'long_agonist';
    return 'antagonist';
  }

  private static generateProtocolRationale(protocol: string, ageScore: number, ovarianReserveScore: number): string {
    const rationales = {
      'antagonist': 'Recommended due to good ovarian reserve and lower OHSS risk with flexible monitoring',
      'long_agonist': 'Optimal for endometriosis patients with better cycle control and synchronization',
      'minimal_stimulation': 'Appropriate for diminished ovarian reserve to minimize medication burden',
      'natural_cycle': 'Suitable for very poor responders or patient preference for minimal intervention'
    };
    return rationales[protocol] || 'Standard protocol based on patient parameters';
  }

  private static generateMedicationPlan(protocol: string, testResults: any, demographics: any): any {
    const baseDose = demographics.age < 35 ? 150 : demographics.age < 40 ? 200 : 250;
    const adjustedDose = testResults.hormones.AMH < 1.0 ? baseDose + 75 : baseDose;

    return {
      gonadotropins: {
        type: testResults.hormones.AMH > 2.0 ? 'rFSH' : 'hMG',
        startingDose: adjustedDose,
        adjustmentStrategy: 'Increase by 75 IU if <3 follicles >10mm on day 6-8'
      },
      antagonist: protocol === 'antagonist' ? {
        type: 'cetrorelix',
        startDay: 6
      } : undefined,
      trigger: {
        type: testResults.hormones.AMH > 3.0 ? 'GnRH_agonist' : 'hCG',
        timing: 'When ≥3 follicles ≥17mm'
      },
      lutealSupport: {
        type: 'progesterone',
        route: 'vaginal',
        duration: '12 weeks if pregnant'
      }
    };
  }

  private static generateMonitoringPlan(protocol: string): any {
    return {
      baselineAssessment: ['Ultrasound', 'E2', 'LH', 'Progesterone'],
      followUpSchedule: [
        { day: 6, tests: ['E2', 'LH'], ultrasound: true },
        { day: 8, tests: ['E2', 'LH'], ultrasound: true },
        { day: 10, tests: ['E2', 'LH', 'Progesterone'], ultrasound: true }
      ],
      cancelationCriteria: ['<3 follicles >10mm on day 10', 'E2 >4000 pg/ml', 'Premature LH surge']
    };
  }

  private static calculateSuccessProbability(ageScore: number, ovarianReserveScore: number, BMI: number, diagnoses: any): any {
    const baseSuccess = 0.4;
    const ageAdjustment = ageScore * 0.3;
    const reserveAdjustment = ovarianReserveScore * 0.2;
    const bmiAdjustment = BMI > 30 ? -0.1 : BMI < 18.5 ? -0.05 : 0;
    
    const clinical = Math.max(0.1, Math.min(0.8, baseSuccess + ageAdjustment + reserveAdjustment + bmiAdjustment));
    const liveBirth = clinical * 0.85;

    return { clinical, liveBirth };
  }

  private static predictOutcomes(ovarianReserveScore: number, age: number): any {
    const baseOocytes = ovarianReserveScore > 0.7 ? 15 : ovarianReserveScore > 0.4 ? 10 : 5;
    const ageAdjustment = age < 35 ? 1.0 : age < 40 ? 0.8 : 0.6;
    
    const expected = Math.round(baseOocytes * ageAdjustment);
    
    return {
      oocytesRetrieved: { min: Math.max(1, expected - 5), max: expected + 8, expected },
      matureOocytes: { min: Math.max(1, expected - 3), max: expected + 3, expected: Math.round(expected * 0.8) },
      blastocysts: { min: 0, max: Math.round(expected * 0.6), expected: Math.round(expected * 0.4) }
    };
  }

  private static assessRisks(demographics: any, testResults: any, medicalHistory: any): any {
    const ohssRisk = testResults.hormones.AMH > 3.0 ? 0.15 : testResults.hormones.AMH > 2.0 ? 0.08 : 0.03;
    const multipleRisk = demographics.age < 35 ? 0.25 : 0.15;
    const cancellationRisk = testResults.hormones.AMH < 0.5 ? 0.3 : 0.1;

    return {
      OHSS: { probability: ohssRisk, severity: ohssRisk > 0.1 ? 'moderate' : 'mild' },
      multiplePregnancy: multipleRisk,
      cancellation: cancellationRisk
    };
  }

  private static generateAlternatives(primaryProtocol: string): any[] {
    const alternatives = {
      'antagonist': [
        { protocol: 'long_agonist', rationale: 'Better cycle control if synchronization needed', confidence: 0.75 },
        { protocol: 'minimal_stimulation', rationale: 'If patient prefers lower medication burden', confidence: 0.65 }
      ],
      'long_agonist': [
        { protocol: 'antagonist', rationale: 'Shorter treatment duration and lower OHSS risk', confidence: 0.80 },
        { protocol: 'short_agonist', rationale: 'Reduced suppression time', confidence: 0.70 }
      ]
    };
    return alternatives[primaryProtocol] || [];
  }

  private static generateWarnings(medicalHistory: any, testResults: any, demographics: any): string[] {
    const warnings = [];
    
    if (demographics.age > 42) {
      warnings.push('Advanced maternal age - consider genetic counseling and PGT-A');
    }
    if (testResults.hormones.AMH < 0.5) {
      warnings.push('Severely diminished ovarian reserve - counsel regarding poor prognosis');
    }
    if (demographics.BMI > 35) {
      warnings.push('Obesity may reduce success rates - recommend weight optimization');
    }
    if (medicalHistory.allergies.includes('gonadotropins')) {
      warnings.push('Gonadotropin allergy documented - use alternative medications');
    }
    
    return warnings;
  }
}
