# 🤝 Contributing to FertiVision Local Development

Thank you for your interest in contributing to FertiVision! This guide will help you get started.

## 🎯 **Ways to Contribute**

### 🐛 **Bug Reports**
- Use the [GitHub Issues](https://github.com/your-username/fertivision-local-dev/issues) page
- Include detailed steps to reproduce
- Provide system information (OS, Python version, etc.)
- Include error messages and logs

### ✨ **Feature Requests**
- Check existing issues first
- Describe the use case and benefits
- Provide mockups or examples if applicable

### 🔧 **Code Contributions**
- Fork the repository
- Create a feature branch
- Follow coding standards
- Add tests for new features
- Update documentation

### 📚 **Documentation**
- Improve README files
- Add code examples
- Fix typos and clarify instructions
- Translate documentation

## 🚀 **Development Setup**

### 1. **Fork and Clone**
```bash
# Fork the repository on GitHub
git clone https://github.com/your-username/fertivision-local-dev.git
cd fertivision-local-dev
```

### 2. **Set Up Environment**
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt  # Development dependencies
```

### 3. **Run Tests**
```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Run specific test file
pytest tests/test_api.py
```

## 📋 **Coding Standards**

### **Python Style**
- Follow PEP 8
- Use Black for formatting: `black .`
- Use flake8 for linting: `flake8 .`
- Maximum line length: 88 characters

### **Code Structure**
```python
# Good example
def analyze_sperm_sample(image_path: str, patient_id: str = None) -> AnalysisResult:
    """
    Analyze sperm sample using WHO 2021 guidelines.
    
    Args:
        image_path: Path to the sperm sample image
        patient_id: Optional patient identifier
        
    Returns:
        AnalysisResult object with classification and parameters
        
    Raises:
        ValueError: If image format is not supported
        FileNotFoundError: If image file doesn't exist
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    
    # Implementation here
    return result
```

### **Documentation**
- Use docstrings for all functions and classes
- Include type hints
- Add inline comments for complex logic
- Update README for new features

## 🧪 **Testing Guidelines**

### **Test Structure**
```python
import pytest
from fertivision_sdk import FertiVisionClient

class TestSpermAnalysis:
    def setup_method(self):
        """Set up test fixtures"""
        self.client = FertiVisionClient(api_key="test_key")
        self.test_image = "tests/fixtures/sperm_sample.jpg"
    
    def test_sperm_analysis_success(self):
        """Test successful sperm analysis"""
        result = self.client.analyze_sperm(self.test_image)
        
        assert result.success is True
        assert result.classification is not None
        assert 0 <= result.confidence <= 100
    
    def test_sperm_analysis_invalid_image(self):
        """Test analysis with invalid image"""
        with pytest.raises(FileNotFoundError):
            self.client.analyze_sperm("nonexistent.jpg")
```

### **Test Coverage**
- Aim for >90% test coverage
- Test both success and error cases
- Include integration tests
- Mock external API calls

## 🔄 **Pull Request Process**

### 1. **Before Submitting**
```bash
# Update your fork
git checkout main
git pull upstream main

# Create feature branch
git checkout -b feature/your-feature-name

# Make your changes
# ...

# Run tests
pytest

# Format code
black .
flake8 .

# Commit changes
git add .
git commit -m "feat: add your feature description"
```

### 2. **Pull Request Template**
```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement

## Testing
- [ ] Tests pass locally
- [ ] Added tests for new features
- [ ] Updated documentation

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No breaking changes
```

### 3. **Review Process**
- Maintainers will review within 48 hours
- Address feedback promptly
- Keep discussions constructive
- Be patient with the review process

## 🏥 **Medical Accuracy**

### **Clinical Validation**
- All medical algorithms must be validated
- Reference medical literature in comments
- Follow established guidelines (WHO, ESHRE, etc.)
- Include confidence intervals and limitations

### **Safety Considerations**
- Never override clinical judgment
- Include appropriate disclaimers
- Validate against known test cases
- Consider edge cases and failure modes

## 🐛 **Bug Report Template**

```markdown
**Bug Description**
Clear description of the bug

**Steps to Reproduce**
1. Go to '...'
2. Click on '....'
3. Upload image '....'
4. See error

**Expected Behavior**
What you expected to happen

**Actual Behavior**
What actually happened

**Environment**
- OS: [e.g., macOS 12.0]
- Python: [e.g., 3.10.0]
- FertiVision Version: [e.g., 1.0.0]

**Additional Context**
- Error messages
- Log files
- Screenshots
```

## 💡 **Feature Request Template**

```markdown
**Feature Description**
Clear description of the proposed feature

**Use Case**
Why is this feature needed?

**Proposed Solution**
How should this feature work?

**Alternatives Considered**
Other approaches you've considered

**Additional Context**
- Mockups
- Examples
- References
```

## 📞 **Getting Help**

### **Community Support**
- [GitHub Discussions](https://github.com/your-username/fertivision-local-dev/discussions)
- [Discord Server](https://discord.gg/fertivision) (coming soon)

### **Direct Contact**
- Email: dev@greybrain.ai
- Issues: GitHub Issues page

## 🏆 **Recognition**

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Annual contributor report

## 📄 **Code of Conduct**

### **Our Standards**
- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow
- Maintain professional communication

### **Unacceptable Behavior**
- Harassment or discrimination
- Trolling or insulting comments
- Publishing private information
- Inappropriate conduct

## 📚 **Resources**

### **Development**
- [Flask Documentation](https://flask.palletsprojects.com/)
- [Python Testing with pytest](https://docs.pytest.org/)
- [Git Workflow](https://guides.github.com/introduction/flow/)

### **Medical References**
- [WHO Laboratory Manual](https://www.who.int/publications/i/item/9789240030787)
- [ESHRE Guidelines](https://www.eshre.eu/Guidelines-and-Legal)
- [Gardner Embryo Grading](https://academic.oup.com/humrep/article/15/6/1212/2915674)

---

**Thank you for contributing to FertiVision! Together, we're advancing reproductive medicine through AI.** 🚀

© 2025 FertiVision powered by AI | Made by greybrain.ai
