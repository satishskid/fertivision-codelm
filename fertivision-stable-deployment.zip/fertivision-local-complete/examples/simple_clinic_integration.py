#!/usr/bin/env python3
"""
Simple Clinic Integration Example for FertiVision Local

This example demonstrates how to integrate FertiVision with a simple clinic workflow.
It processes daily sperm analyses and stores results in CSV format.

Usage:
    python simple_clinic_integration.py --folder daily_images
"""

import os
import csv
import argparse
from datetime import datetime
from pathlib import Path
import sys

# Add parent directory to path to import fertivision_sdk
sys.path.append(str(Path(__file__).parent.parent))

try:
    from fertivision_sdk import FertiVisionClient
except ImportError:
    print("❌ Error: fertivision_sdk not found. Make sure you're running from the correct directory.")
    sys.exit(1)


class SimpleClinicIntegration:
    """Simple clinic integration for daily sperm analysis processing."""
    
    def __init__(self, api_key="fv_demo_key_12345", base_url="http://localhost:5004"):
        """
        Initialize the clinic integration.
        
        Args:
            api_key: FertiVision API key (default: demo key)
            base_url: FertiVision API base URL
        """
        self.client = FertiVisionClient(api_key=api_key, base_url=base_url)
        self.results_folder = "analysis_results"
        self.setup_folders()
        
    def setup_folders(self):
        """Create necessary folders for storing results."""
        os.makedirs(self.results_folder, exist_ok=True)
        print(f"📁 Results will be saved to: {self.results_folder}")
    
    def validate_image(self, image_path):
        """
        Validate if image is suitable for analysis.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            bool: True if image is valid, False otherwise
        """
        # Check file exists
        if not os.path.exists(image_path):
            return False
            
        # Check file size (max 50MB)
        file_size = os.path.getsize(image_path) / (1024 * 1024)  # MB
        if file_size > 50:
            print(f"⚠️ Warning: {image_path} is too large ({file_size:.1f}MB)")
            return False
            
        # Check file extension
        valid_extensions = ['.jpg', '.jpeg', '.png', '.tiff', '.bmp']
        if not any(image_path.lower().endswith(ext) for ext in valid_extensions):
            return False
            
        return True
    
    def extract_patient_info(self, filename):
        """
        Extract patient information from filename.
        
        Expected format: PatientID_Date_SampleType.jpg
        Example: P12345_20250113_sperm.jpg
        
        Args:
            filename: Image filename
            
        Returns:
            dict: Patient information
        """
        try:
            # Remove extension
            name_without_ext = os.path.splitext(filename)[0]
            
            # Split by underscore
            parts = name_without_ext.split('_')
            
            if len(parts) >= 2:
                return {
                    'patient_id': parts[0],
                    'date': parts[1] if len(parts) > 1 else datetime.now().strftime('%Y%m%d'),
                    'sample_type': parts[2] if len(parts) > 2 else 'sperm'
                }
            else:
                # Fallback: use filename as patient ID
                return {
                    'patient_id': name_without_ext,
                    'date': datetime.now().strftime('%Y%m%d'),
                    'sample_type': 'sperm'
                }
        except Exception:
            # Ultimate fallback
            return {
                'patient_id': f"UNKNOWN_{datetime.now().strftime('%H%M%S')}",
                'date': datetime.now().strftime('%Y%m%d'),
                'sample_type': 'sperm'
            }
    
    def process_single_image(self, image_path):
        """
        Process a single image for sperm analysis.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            dict: Analysis result or None if failed
        """
        filename = os.path.basename(image_path)
        
        # Validate image
        if not self.validate_image(image_path):
            print(f"❌ Invalid image: {filename}")
            return None
        
        # Extract patient info
        patient_info = self.extract_patient_info(filename)
        
        try:
            print(f"🔬 Analyzing {filename} for patient {patient_info['patient_id']}...")
            
            # Perform sperm analysis
            result = self.client.analyze_sperm(
                image_path=image_path,
                patient_id=patient_info['patient_id'],
                notes=f"Processed on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            if result.success:
                analysis_result = {
                    'timestamp': datetime.now().isoformat(),
                    'filename': filename,
                    'patient_id': patient_info['patient_id'],
                    'sample_date': patient_info['date'],
                    'classification': result.classification,
                    'confidence': result.confidence,
                    'concentration': result.parameters.get('concentration', 'N/A'),
                    'progressive_motility': result.parameters.get('progressive_motility', 'N/A'),
                    'normal_morphology': result.parameters.get('normal_morphology', 'N/A'),
                    'processing_time': getattr(result, 'processing_time', 'N/A'),
                    'status': 'success'
                }
                
                print(f"✅ Success: {result.classification} (Confidence: {result.confidence}%)")
                return analysis_result
            else:
                print(f"❌ Analysis failed for {filename}")
                return {
                    'timestamp': datetime.now().isoformat(),
                    'filename': filename,
                    'patient_id': patient_info['patient_id'],
                    'status': 'failed',
                    'error': 'Analysis failed'
                }
                
        except Exception as e:
            print(f"❌ Error processing {filename}: {str(e)}")
            return {
                'timestamp': datetime.now().isoformat(),
                'filename': filename,
                'patient_id': patient_info['patient_id'],
                'status': 'error',
                'error': str(e)
            }
    
    def process_folder(self, folder_path):
        """
        Process all images in a folder.
        
        Args:
            folder_path: Path to folder containing images
            
        Returns:
            list: List of analysis results
        """
        if not os.path.exists(folder_path):
            print(f"❌ Folder not found: {folder_path}")
            return []
        
        # Find all image files
        image_extensions = ['.jpg', '.jpeg', '.png', '.tiff', '.bmp']
        image_files = []
        
        for filename in os.listdir(folder_path):
            if any(filename.lower().endswith(ext) for ext in image_extensions):
                image_files.append(os.path.join(folder_path, filename))
        
        if not image_files:
            print(f"⚠️ No image files found in {folder_path}")
            return []
        
        print(f"📸 Found {len(image_files)} image(s) to process")
        
        # Process each image
        results = []
        for i, image_path in enumerate(image_files, 1):
            print(f"\n[{i}/{len(image_files)}] Processing {os.path.basename(image_path)}")
            result = self.process_single_image(image_path)
            if result:
                results.append(result)
        
        return results
    
    def save_results_csv(self, results):
        """
        Save analysis results to CSV file.
        
        Args:
            results: List of analysis results
            
        Returns:
            str: Path to saved CSV file
        """
        if not results:
            print("⚠️ No results to save")
            return None
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_filename = f"sperm_analysis_results_{timestamp}.csv"
        csv_path = os.path.join(self.results_folder, csv_filename)
        
        # Define CSV headers
        headers = [
            'timestamp', 'filename', 'patient_id', 'sample_date',
            'classification', 'confidence', 'concentration',
            'progressive_motility', 'normal_morphology',
            'processing_time', 'status', 'error'
        ]
        
        try:
            with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=headers)
                writer.writeheader()
                
                for result in results:
                    # Ensure all headers are present
                    row = {header: result.get(header, '') for header in headers}
                    writer.writerow(row)
            
            print(f"📊 Results saved to: {csv_path}")
            return csv_path
            
        except Exception as e:
            print(f"❌ Error saving CSV: {str(e)}")
            return None
    
    def generate_summary_report(self, results):
        """
        Generate a summary report of the analysis results.
        
        Args:
            results: List of analysis results
        """
        if not results:
            return
        
        print("\n" + "="*60)
        print("📋 ANALYSIS SUMMARY REPORT")
        print("="*60)
        
        # Count results by status
        successful = [r for r in results if r.get('status') == 'success']
        failed = [r for r in results if r.get('status') in ['failed', 'error']]
        
        print(f"Total Images Processed: {len(results)}")
        print(f"Successful Analyses: {len(successful)}")
        print(f"Failed Analyses: {len(failed)}")
        
        if successful:
            print(f"\nSuccess Rate: {len(successful)/len(results)*100:.1f}%")
            
            # Classification summary
            classifications = {}
            confidences = []
            
            for result in successful:
                classification = result.get('classification', 'Unknown')
                classifications[classification] = classifications.get(classification, 0) + 1
                
                confidence = result.get('confidence')
                if confidence and confidence != 'N/A':
                    confidences.append(float(confidence))
            
            print("\n📊 Classification Results:")
            for classification, count in classifications.items():
                percentage = count / len(successful) * 100
                print(f"  {classification}: {count} ({percentage:.1f}%)")
            
            if confidences:
                avg_confidence = sum(confidences) / len(confidences)
                print(f"\n🎯 Average Confidence: {avg_confidence:.1f}%")
        
        if failed:
            print(f"\n❌ Failed Analyses:")
            for result in failed:
                error = result.get('error', 'Unknown error')
                print(f"  {result.get('filename', 'Unknown')}: {error}")
        
        print("="*60)


def main():
    """Main function to run the clinic integration."""
    parser = argparse.ArgumentParser(
        description="FertiVision Simple Clinic Integration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python simple_clinic_integration.py --folder daily_images
  python simple_clinic_integration.py --folder /path/to/images --api-key your_key
  python simple_clinic_integration.py --image single_image.jpg
        """
    )
    
    parser.add_argument(
        '--folder', '-f',
        help='Folder containing images to process'
    )
    
    parser.add_argument(
        '--image', '-i',
        help='Single image file to process'
    )
    
    parser.add_argument(
        '--api-key', '-k',
        default='fv_demo_key_12345',
        help='FertiVision API key (default: demo key)'
    )
    
    parser.add_argument(
        '--api-url', '-u',
        default='http://localhost:5004',
        help='FertiVision API URL (default: http://localhost:5004)'
    )
    
    args = parser.parse_args()
    
    # Validate arguments
    if not args.folder and not args.image:
        parser.error("Either --folder or --image must be specified")
    
    # Initialize clinic integration
    print("🔬 FertiVision Simple Clinic Integration")
    print("="*50)
    
    try:
        clinic = SimpleClinicIntegration(
            api_key=args.api_key,
            base_url=args.api_url
        )
        
        # Test API connection
        print("🔌 Testing API connection...")
        health = clinic.client.health_check()
        if health.get('status') == 'healthy':
            print("✅ API connection successful")
        else:
            print("⚠️ API connection warning - continuing with demo mode")
        
    except Exception as e:
        print(f"❌ Failed to initialize: {str(e)}")
        return 1
    
    # Process images
    results = []
    
    if args.folder:
        print(f"\n📁 Processing folder: {args.folder}")
        results = clinic.process_folder(args.folder)
    elif args.image:
        print(f"\n📸 Processing single image: {args.image}")
        result = clinic.process_single_image(args.image)
        if result:
            results = [result]
    
    # Save results and generate report
    if results:
        clinic.save_results_csv(results)
        clinic.generate_summary_report(results)
        print("\n🎉 Processing complete!")
        return 0
    else:
        print("\n⚠️ No results to save")
        return 1


if __name__ == "__main__":
    exit(main())
