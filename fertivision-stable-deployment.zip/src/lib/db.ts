import { sql } from '@vercel/postgres';
import { kv } from '@vercel/kv';

// Database schema types
export interface User {
  id: number;
  clerk_user_id: string;
  email: string;
  full_name?: string;
  subscription_plan: 'free' | 'professional' | 'enterprise';
  analyses_used: number;
  analyses_limit: number;
  created_at: Date;
  updated_at: Date;
}

export interface Analysis {
  id: number;
  user_id: number;
  analysis_type: 'sperm' | 'oocyte' | 'embryo' | 'follicle' | 'hysteroscopy';
  image_url?: string;
  image_filename?: string;
  patient_id?: string;
  case_id?: string;
  results: any;
  confidence?: number;
  processing_time?: number;
  created_at: Date;
}

export interface Subscription {
  id: number;
  user_id: number;
  razorpay_subscription_id?: string;
  plan_id: string;
  status: 'created' | 'active' | 'paused' | 'cancelled' | 'expired';
  current_period_start?: Date;
  current_period_end?: Date;
  created_at: Date;
  updated_at: Date;
}

export interface AppConfig {
  id: number;
  key: string;
  value: string;
  description?: string;
  updated_at: Date;
}

// Initialize database tables
export async function initializeDatabase() {
  try {
    // Users table
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        clerk_user_id VARCHAR(255) UNIQUE NOT NULL,
        email VARCHAR(255) NOT NULL,
        full_name VARCHAR(255),
        subscription_plan VARCHAR(50) DEFAULT 'free',
        analyses_used INTEGER DEFAULT 0,
        analyses_limit INTEGER DEFAULT 10,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `;

    // Analyses table
    await sql`
      CREATE TABLE IF NOT EXISTS analyses (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        analysis_type VARCHAR(50) NOT NULL,
        image_url VARCHAR(500),
        image_filename VARCHAR(255),
        patient_id VARCHAR(100),
        case_id VARCHAR(100),
        results JSONB NOT NULL,
        confidence DECIMAL(5,2),
        processing_time DECIMAL(8,3),
        created_at TIMESTAMP DEFAULT NOW()
      )
    `;

    // Subscriptions table
    await sql`
      CREATE TABLE IF NOT EXISTS subscriptions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        razorpay_subscription_id VARCHAR(255) UNIQUE,
        plan_id VARCHAR(50) NOT NULL,
        status VARCHAR(50) DEFAULT 'created',
        current_period_start TIMESTAMP,
        current_period_end TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `;

    // App configuration table
    await sql`
      CREATE TABLE IF NOT EXISTS app_config (
        id SERIAL PRIMARY KEY,
        key VARCHAR(100) UNIQUE NOT NULL,
        value TEXT NOT NULL,
        description TEXT,
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `;

    // Usage logs table
    await sql`
      CREATE TABLE IF NOT EXISTS usage_logs (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        analysis_id INTEGER REFERENCES analyses(id) ON DELETE CASCADE,
        action VARCHAR(100) NOT NULL,
        metadata JSONB,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `;

    // Create indexes
    await sql`CREATE INDEX IF NOT EXISTS idx_users_clerk_id ON users(clerk_user_id)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_analyses_user_id ON analyses(user_id)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_analyses_created_at ON analyses(created_at)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id)`;
    await sql`CREATE INDEX IF NOT EXISTS idx_usage_logs_user_id ON usage_logs(user_id)`;

    console.log('Database initialized successfully');
    return true;
  } catch (error) {
    console.error('Database initialization error:', error);
    return false;
  }
}

// User operations
export async function createUser(clerkUserId: string, email: string, fullName?: string): Promise<User | null> {
  try {
    const result = await sql`
      INSERT INTO users (clerk_user_id, email, full_name)
      VALUES (${clerkUserId}, ${email}, ${fullName})
      ON CONFLICT (clerk_user_id) DO UPDATE SET
        email = EXCLUDED.email,
        full_name = EXCLUDED.full_name,
        updated_at = NOW()
      RETURNING *
    `;
    return result.rows[0] as User;
  } catch (error) {
    console.error('Error creating user:', error);
    return null;
  }
}

export async function getUserByClerkId(clerkUserId: string): Promise<User | null> {
  try {
    const result = await sql`
      SELECT * FROM users WHERE clerk_user_id = ${clerkUserId}
    `;
    return result.rows[0] as User || null;
  } catch (error) {
    console.error('Error getting user:', error);
    return null;
  }
}

export async function updateUserSubscription(
  userId: number, 
  plan: 'free' | 'professional' | 'enterprise',
  analysesLimit: number
): Promise<boolean> {
  try {
    await sql`
      UPDATE users 
      SET subscription_plan = ${plan}, 
          analyses_limit = ${analysesLimit},
          updated_at = NOW()
      WHERE id = ${userId}
    `;
    return true;
  } catch (error) {
    console.error('Error updating user subscription:', error);
    return false;
  }
}

export async function incrementUserUsage(userId: number): Promise<boolean> {
  try {
    await sql`
      UPDATE users 
      SET analyses_used = analyses_used + 1,
          updated_at = NOW()
      WHERE id = ${userId}
    `;
    return true;
  } catch (error) {
    console.error('Error incrementing user usage:', error);
    return false;
  }
}

// Analysis operations
export async function saveAnalysis(
  userId: number,
  analysisType: string,
  results: any,
  imageUrl?: string,
  imageFilename?: string,
  patientId?: string,
  caseId?: string,
  confidence?: number,
  processingTime?: number
): Promise<Analysis | null> {
  try {
    const result = await sql`
      INSERT INTO analyses (
        user_id, analysis_type, results, image_url, image_filename,
        patient_id, case_id, confidence, processing_time
      )
      VALUES (
        ${userId}, ${analysisType}, ${JSON.stringify(results)}, ${imageUrl}, ${imageFilename},
        ${patientId}, ${caseId}, ${confidence}, ${processingTime}
      )
      RETURNING *
    `;
    return result.rows[0] as Analysis;
  } catch (error) {
    console.error('Error saving analysis:', error);
    return null;
  }
}

export async function getUserAnalyses(userId: number, limit: number = 50): Promise<Analysis[]> {
  try {
    const result = await sql`
      SELECT * FROM analyses 
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
      LIMIT ${limit}
    `;
    return result.rows as Analysis[];
  } catch (error) {
    console.error('Error getting user analyses:', error);
    return [];
  }
}

// Subscription operations
export async function createSubscription(
  userId: number,
  planId: string,
  razorpaySubscriptionId?: string
): Promise<Subscription | null> {
  try {
    const result = await sql`
      INSERT INTO subscriptions (user_id, plan_id, razorpay_subscription_id)
      VALUES (${userId}, ${planId}, ${razorpaySubscriptionId})
      RETURNING *
    `;
    return result.rows[0] as Subscription;
  } catch (error) {
    console.error('Error creating subscription:', error);
    return null;
  }
}

export async function updateSubscriptionStatus(
  subscriptionId: number,
  status: string,
  periodStart?: Date,
  periodEnd?: Date
): Promise<boolean> {
  try {
    await sql`
      UPDATE subscriptions 
      SET status = ${status},
          current_period_start = ${periodStart?.toISOString()},
          current_period_end = ${periodEnd?.toISOString()},
          updated_at = NOW()
      WHERE id = ${subscriptionId}
    `;
    return true;
  } catch (error) {
    console.error('Error updating subscription status:', error);
    return false;
  }
}

// App configuration operations
export async function getAppConfig(key: string): Promise<string | null> {
  try {
    const result = await sql`
      SELECT value FROM app_config WHERE key = ${key}
    `;
    return result.rows[0]?.value || null;
  } catch (error) {
    console.error('Error getting app config:', error);
    return null;
  }
}

export async function setAppConfig(key: string, value: string, description?: string): Promise<boolean> {
  try {
    await sql`
      INSERT INTO app_config (key, value, description)
      VALUES (${key}, ${value}, ${description})
      ON CONFLICT (key) DO UPDATE SET
        value = EXCLUDED.value,
        description = EXCLUDED.description,
        updated_at = NOW()
    `;
    return true;
  } catch (error) {
    console.error('Error setting app config:', error);
    return false;
  }
}

// Cache operations using Vercel KV
export async function cacheSet(key: string, value: any, ttl: number = 3600): Promise<boolean> {
  try {
    await kv.set(key, JSON.stringify(value), { ex: ttl });
    return true;
  } catch (error) {
    console.error('Error setting cache:', error);
    return false;
  }
}

export async function cacheGet(key: string): Promise<any> {
  try {
    const value = await kv.get(key);
    return value ? JSON.parse(value as string) : null;
  } catch (error) {
    console.error('Error getting cache:', error);
    return null;
  }
}

export async function cacheDelete(key: string): Promise<boolean> {
  try {
    await kv.del(key);
    return true;
  } catch (error) {
    console.error('Error deleting cache:', error);
    return false;
  }
}
