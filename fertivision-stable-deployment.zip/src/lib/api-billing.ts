// API Billing and Usage Tracking System

export interface APISubscription {
  userId: string;
  plan: 'free' | 'professional' | 'enterprise' | 'custom';
  limits: {
    requestsPerMonth: number;
    requestsPerDay: number;
    requestsPerHour: number;
  };
  pricing: {
    basePrice: number; // Monthly base price
    perRequestPrice: number; // Price per API request
    overage: number; // Price for requests over limit
  };
  customBilling?: {
    enabled: boolean;
    billingPeriod: 'daily' | 'weekly' | 'monthly' | 'yearly';
    customLimits: {
      requests: number;
      period: string;
    };
    customPricing: {
      basePrice: number;
      perRequestPrice: number;
    };
  };
  features: string[];
  startDate: Date;
  endDate: Date;
  status: 'active' | 'suspended' | 'cancelled';
}

export interface APIUsage {
  userId: string;
  requestId: string;
  analysisType: 'sperm' | 'oocyte' | 'embryo' | 'follicle' | 'treatment-plan' | 'stimulation-protocol' | 'outcome-prediction';
  timestamp: Date;
  requestSize: number;
  responseSize?: number;
  processingTime: number;
  cost: number;
  userAgent: string;
  ipAddress?: string;
  success: boolean;
  errorCode?: string;
}

// Default subscription plans
const DEFAULT_PLANS: Record<string, Omit<APISubscription, 'userId' | 'startDate' | 'endDate' | 'status'>> = {
  free: {
    plan: 'free',
    limits: {
      requestsPerMonth: 100,
      requestsPerDay: 10,
      requestsPerHour: 5
    },
    pricing: {
      basePrice: 0,
      perRequestPrice: 0,
      overage: 0.50, // ₹0.50 per request over limit
      clinicalAPIs: {
        'treatment-plan': 5.00,
        'stimulation-protocol': 7.50,
        'outcome-prediction': 10.00
      }
    },
    features: ['Basic AI Analysis', 'Standard Support', 'API Documentation']
  },
  professional: {
    plan: 'professional',
    limits: {
      requestsPerMonth: 5000,
      requestsPerDay: 200,
      requestsPerHour: 50
    },
    pricing: {
      basePrice: 299,
      perRequestPrice: 0.10,
      overage: 0.25,
      clinicalAPIs: {
        'treatment-plan': 25.00,
        'stimulation-protocol': 30.00,
        'outcome-prediction': 35.00
      }
    },
    features: [
      'Advanced AI Analysis',
      'Priority Support',
      'API Documentation',
      'Usage Analytics',
      'Export Reports'
    ]
  },
  enterprise: {
    plan: 'enterprise',
    limits: {
      requestsPerMonth: 50000,
      requestsPerDay: 2000,
      requestsPerHour: 500
    },
    pricing: {
      basePrice: 999,
      perRequestPrice: 0.05,
      overage: 0.15,
      clinicalAPIs: {
        'treatment-plan': 15.00,
        'stimulation-protocol': 20.00,
        'outcome-prediction': 25.00
      }
    },
    features: [
      'Premium AI Analysis',
      '24/7 Support',
      'API Documentation',
      'Advanced Analytics',
      'Custom Integration',
      'Dedicated Account Manager',
      'SLA Guarantee'
    ]
  }
};

// In-memory storage (replace with database in production)
const subscriptions = new Map<string, APISubscription>();
const usageData = new Map<string, APIUsage[]>();

export async function getUserSubscription(userId: string): Promise<APISubscription> {
  let subscription = subscriptions.get(userId);
  
  if (!subscription) {
    // Create default free subscription
    subscription = {
      userId,
      ...DEFAULT_PLANS.free,
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      status: 'active'
    };
    subscriptions.set(userId, subscription);
  }
  
  return subscription;
}

export async function updateUserSubscription(
  userId: string, 
  plan: 'professional' | 'enterprise' | 'custom',
  customConfig?: Partial<APISubscription>
): Promise<APISubscription> {
  const baseSubscription = plan === 'custom' ? customConfig : DEFAULT_PLANS[plan];
  
  const subscription: APISubscription = {
    userId,
    ...baseSubscription,
    startDate: new Date(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    status: 'active'
  } as APISubscription;
  
  subscriptions.set(userId, subscription);
  return subscription;
}

export async function checkAPILimits(userId: string, subscription: APISubscription) {
  const now = new Date();
  const userUsage = usageData.get(userId) || [];
  
  // Check if subscription is active
  if (subscription.status !== 'active' || now > subscription.endDate) {
    return {
      allowed: false,
      message: 'Subscription expired or inactive',
      usage: await getUsageStats(userId),
      remaining: 0,
      resetDate: subscription.endDate
    };
  }
  
  // Calculate usage for different periods
  const hourStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours());
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  const hourlyUsage = userUsage.filter(u => u.timestamp >= hourStart && u.success).length;
  const dailyUsage = userUsage.filter(u => u.timestamp >= dayStart && u.success).length;
  const monthlyUsage = userUsage.filter(u => u.timestamp >= monthStart && u.success).length;
  
  // Check limits
  if (hourlyUsage >= subscription.limits.requestsPerHour) {
    return {
      allowed: false,
      message: 'Hourly limit exceeded',
      usage: { hourly: hourlyUsage, daily: dailyUsage, monthly: monthlyUsage },
      remaining: 0,
      resetDate: new Date(hourStart.getTime() + 60 * 60 * 1000)
    };
  }
  
  if (dailyUsage >= subscription.limits.requestsPerDay) {
    return {
      allowed: false,
      message: 'Daily limit exceeded',
      usage: { hourly: hourlyUsage, daily: dailyUsage, monthly: monthlyUsage },
      remaining: 0,
      resetDate: new Date(dayStart.getTime() + 24 * 60 * 60 * 1000)
    };
  }
  
  if (monthlyUsage >= subscription.limits.requestsPerMonth) {
    return {
      allowed: false,
      message: 'Monthly limit exceeded',
      usage: { hourly: hourlyUsage, daily: dailyUsage, monthly: monthlyUsage },
      remaining: 0,
      resetDate: new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 1)
    };
  }
  
  return {
    allowed: true,
    message: 'Within limits',
    usage: { hourly: hourlyUsage, daily: dailyUsage, monthly: monthlyUsage },
    remaining: subscription.limits.requestsPerMonth - monthlyUsage,
    resetDate: new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 1)
  };
}

export async function trackAPIUsage(
  userId: string,
  analysisType: 'sperm' | 'oocyte' | 'embryo' | 'follicle' | 'treatment-plan' | 'stimulation-protocol' | 'outcome-prediction',
  metadata: {
    timestamp: Date;
    requestSize: number;
    userAgent: string;
    responseSize?: number;
    processingTime?: number;
    success?: boolean;
    errorCode?: string;
  }
): Promise<void> {
  const subscription = await getUserSubscription(userId);

  // Calculate cost based on API type
  let cost = subscription.pricing.perRequestPrice;

  // Clinical APIs have special pricing
  const clinicalAPIs = ['treatment-plan', 'stimulation-protocol', 'outcome-prediction'];
  if (clinicalAPIs.includes(analysisType)) {
    cost = subscription.pricing.clinicalAPIs?.[analysisType] || subscription.pricing.perRequestPrice * 10;
  } else {
    // Check if this is an overage request for basic APIs
    const monthStart = new Date(metadata.timestamp.getFullYear(), metadata.timestamp.getMonth(), 1);
    const userUsage = usageData.get(userId) || [];
    const monthlyUsage = userUsage.filter(u => u.timestamp >= monthStart && u.success).length;

    if (monthlyUsage >= subscription.limits.requestsPerMonth) {
      cost = subscription.pricing.overage;
    }
  }
  
  const usage: APIUsage = {
    userId,
    requestId: generateRequestId(),
    analysisType,
    timestamp: metadata.timestamp,
    requestSize: metadata.requestSize,
    responseSize: metadata.responseSize || 0,
    processingTime: metadata.processingTime || 0,
    cost,
    userAgent: metadata.userAgent,
    success: metadata.success !== false,
    errorCode: metadata.errorCode
  };
  
  const existingUsage = usageData.get(userId) || [];
  existingUsage.push(usage);
  usageData.set(userId, existingUsage);
}

export async function getUsageStats(userId: string, period?: 'hour' | 'day' | 'month' | 'year') {
  const userUsage = usageData.get(userId) || [];
  const now = new Date();
  
  let startDate: Date;
  switch (period) {
    case 'hour':
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours());
      break;
    case 'day':
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      break;
    case 'month':
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      break;
    case 'year':
      startDate = new Date(now.getFullYear(), 0, 1);
      break;
    default:
      startDate = new Date(now.getFullYear(), now.getMonth(), 1); // Default to month
  }
  
  const periodUsage = userUsage.filter(u => u.timestamp >= startDate);
  
  return {
    totalRequests: periodUsage.length,
    successfulRequests: periodUsage.filter(u => u.success).length,
    failedRequests: periodUsage.filter(u => !u.success).length,
    totalCost: periodUsage.reduce((sum, u) => sum + u.cost, 0),
    averageProcessingTime: periodUsage.reduce((sum, u) => sum + u.processingTime, 0) / periodUsage.length || 0,
    analysisBreakdown: {
      sperm: periodUsage.filter(u => u.analysisType === 'sperm').length,
      oocyte: periodUsage.filter(u => u.analysisType === 'oocyte').length,
      embryo: periodUsage.filter(u => u.analysisType === 'embryo').length,
      follicle: periodUsage.filter(u => u.analysisType === 'follicle').length,
      'treatment-plan': periodUsage.filter(u => u.analysisType === 'treatment-plan').length,
      'stimulation-protocol': periodUsage.filter(u => u.analysisType === 'stimulation-protocol').length,
      'outcome-prediction': periodUsage.filter(u => u.analysisType === 'outcome-prediction').length
    },
    period: period || 'month',
    startDate,
    endDate: now
  };
}

export async function createCustomBilling(
  userId: string,
  config: {
    billingPeriod: 'daily' | 'weekly' | 'monthly' | 'yearly';
    requestLimit: number;
    basePrice: number;
    perRequestPrice: number;
    overagePrice: number;
  }
): Promise<APISubscription> {
  const customSubscription: APISubscription = {
    userId,
    plan: 'custom',
    limits: {
      requestsPerMonth: config.requestLimit,
      requestsPerDay: Math.floor(config.requestLimit / 30),
      requestsPerHour: Math.floor(config.requestLimit / (30 * 24))
    },
    pricing: {
      basePrice: config.basePrice,
      perRequestPrice: config.perRequestPrice,
      overage: config.overagePrice
    },
    customBilling: {
      enabled: true,
      billingPeriod: config.billingPeriod,
      customLimits: {
        requests: config.requestLimit,
        period: config.billingPeriod
      },
      customPricing: {
        basePrice: config.basePrice,
        perRequestPrice: config.perRequestPrice
      }
    },
    features: [
      'Custom AI Analysis',
      'Dedicated Support',
      'Custom Integration',
      'Advanced Analytics',
      'Custom Billing'
    ],
    startDate: new Date(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    status: 'active'
  };
  
  subscriptions.set(userId, customSubscription);
  return customSubscription;
}

function generateRequestId(): string {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
