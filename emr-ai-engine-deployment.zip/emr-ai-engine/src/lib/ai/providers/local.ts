/**
 * Local AI Providers for High-Performance EMR AI Engine
 * Optimized for privacy, low latency, and offline operation
 */

import { performance } from 'perf_hooks';
import { pipeline, env } from '@xenova/transformers';
import * as ort from 'onnxruntime-node';

interface AIProvider {
  name: string;
  type: 'local' | 'cloud';
  priority: number;
  costPerToken: number;
  avgResponseTime: number;
  maxTokens: number;
  isAvailable(): Promise<boolean>;
  generateResponse(prompt: string, options?: any): Promise<AIResponse>;
}

interface AIResponse {
  content: string;
  confidence: number;
  tokensUsed: number;
  responseTime: number;
  model: string;
  provider: string;
  cached: boolean;
}

/**
 * Ollama Local Provider
 * High-performance local LLM serving
 */
export class OllamaProvider implements AIProvider {
  name = 'ollama';
  type: 'local' | 'cloud' = 'local';
  priority = 1; // Highest priority for local
  costPerToken = 0; // Free local processing
  avgResponseTime = 150; // ms
  maxTokens = 8192;

  private baseUrl: string;
  private availableModels: string[];
  private isHealthy = false;

  constructor(config: { baseUrl: string; models: string[] }) {
    this.baseUrl = config.baseUrl;
    this.availableModels = config.models;
    this.checkHealth();
  }

  async isAvailable(): Promise<boolean> {
    return this.isHealthy;
  }

  private async checkHealth(): Promise<void> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      if (response.ok) {
        const data = await response.json();
        this.isHealthy = data.models && data.models.length > 0;
        
        // Update available models
        this.availableModels = data.models.map((m: any) => m.name);
      }
    } catch (error) {
      this.isHealthy = false;
      console.warn('Ollama not available:', error);
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isHealthy) {
      throw new Error('Ollama provider not available');
    }

    // Select best model for the task
    const model = this.selectModel(options.requestType || 'general');
    
    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          prompt: this.formatPrompt(prompt, options),
          stream: false,
          options: {
            temperature: options.temperature || 0.7,
            top_p: options.top_p || 0.9,
            max_tokens: options.max_tokens || 1000,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.statusText}`);
      }

      const data = await response.json();
      const responseTime = performance.now() - startTime;

      return {
        content: data.response,
        confidence: this.calculateConfidence(data),
        tokensUsed: this.estimateTokens(prompt + data.response),
        responseTime,
        model,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`Ollama generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    // Model selection based on request type
    const modelMap: { [key: string]: string } = {
      'medical': 'llama3.2:3b', // Best for medical tasks
      'general': 'phi3.5:mini', // Fast general purpose
      'clinical': 'biogpt:base', // Specialized for clinical text
      'summary': 'llama3.2:3b', // Good for summarization
    };

    return modelMap[requestType] || this.availableModels[0] || 'llama3.2:3b';
  }

  private formatPrompt(prompt: string, options: any): string {
    const systemPrompt = options.systemPrompt || 
      'You are a helpful medical AI assistant. Provide accurate, evidence-based responses.';
    
    return `${systemPrompt}\n\nHuman: ${prompt}\n\nAssistant:`;
  }

  private calculateConfidence(data: any): number {
    // Simple confidence calculation based on response characteristics
    const responseLength = data.response?.length || 0;
    const hasStructure = /\d+\.|\-|\*/.test(data.response || '');
    
    let confidence = 0.7; // Base confidence
    
    if (responseLength > 100) confidence += 0.1;
    if (hasStructure) confidence += 0.1;
    if (data.done) confidence += 0.1;
    
    return Math.min(confidence, 1.0);
  }

  private estimateTokens(text: string): number {
    // Rough token estimation (1 token ≈ 4 characters)
    return Math.ceil(text.length / 4);
  }
}

/**
 * Hugging Face Local Provider
 * Using Transformers.js for browser/Node.js inference
 */
export class HuggingFaceLocalProvider implements AIProvider {
  name = 'huggingface-local';
  type: 'local' | 'cloud' = 'local';
  priority = 2;
  costPerToken = 0;
  avgResponseTime = 300; // ms
  maxTokens = 2048;

  private models: Map<string, any> = new Map();
  private isInitialized = false;

  constructor(config: { models: string[] }) {
    this.initializeModels(config.models);
  }

  async isAvailable(): Promise<boolean> {
    return this.isInitialized;
  }

  private async initializeModels(modelNames: string[]): Promise<void> {
    try {
      // Set cache directory for models
      env.cacheDir = './models/huggingface';
      
      for (const modelName of modelNames) {
        try {
          // Load text generation pipeline
          const generator = await pipeline('text-generation', modelName, {
            device: 'cpu', // Use CPU for compatibility
            dtype: 'fp32',
          });
          
          this.models.set(modelName, generator);
          console.log(`Loaded model: ${modelName}`);
        } catch (error) {
          console.warn(`Failed to load model ${modelName}:`, error);
        }
      }
      
      this.isInitialized = this.models.size > 0;
    } catch (error) {
      console.error('Failed to initialize HuggingFace models:', error);
      this.isInitialized = false;
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isInitialized) {
      throw new Error('HuggingFace local provider not initialized');
    }

    const modelName = this.selectModel(options.requestType || 'general');
    const model = this.models.get(modelName);
    
    if (!model) {
      throw new Error(`Model ${modelName} not available`);
    }

    try {
      const result = await model(prompt, {
        max_new_tokens: options.max_tokens || 200,
        temperature: options.temperature || 0.7,
        do_sample: true,
        return_full_text: false,
      });

      const responseTime = performance.now() - startTime;
      const generatedText = result[0]?.generated_text || '';

      return {
        content: generatedText,
        confidence: this.calculateConfidence(result[0]),
        tokensUsed: this.estimateTokens(prompt + generatedText),
        responseTime,
        model: modelName,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`HuggingFace generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    const modelMap: { [key: string]: string } = {
      'medical': 'microsoft/BioGPT',
      'clinical': 'emilyalsentzer/Bio_ClinicalBERT',
      'general': 'microsoft/DialoGPT-medium',
    };

    const selectedModel = modelMap[requestType];
    
    // Return the selected model if available, otherwise return the first available model
    if (selectedModel && this.models.has(selectedModel)) {
      return selectedModel;
    }
    
    return Array.from(this.models.keys())[0];
  }

  private calculateConfidence(result: any): number {
    // Use model's confidence score if available
    if (result?.score) {
      return result.score;
    }
    
    // Fallback confidence calculation
    const textLength = result?.generated_text?.length || 0;
    return Math.min(0.6 + (textLength / 1000), 0.95);
  }

  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }
}

/**
 * ONNX Runtime Provider
 * Optimized inference using ONNX models
 */
export class ONNXProvider implements AIProvider {
  name = 'onnx';
  type: 'local' | 'cloud' = 'local';
  priority = 3;
  costPerToken = 0;
  avgResponseTime = 100; // Very fast inference
  maxTokens = 1024;

  private session: ort.InferenceSession | null = null;
  private tokenizer: any = null;
  private isReady = false;

  constructor(config: { modelPath: string; tokenizerPath: string }) {
    this.initializeModel(config.modelPath, config.tokenizerPath);
  }

  async isAvailable(): Promise<boolean> {
    return this.isReady;
  }

  private async initializeModel(modelPath: string, tokenizerPath: string): Promise<void> {
    try {
      // Load ONNX model
      this.session = await ort.InferenceSession.create(modelPath, {
        executionProviders: ['cpu'], // Use CPU provider for compatibility
        graphOptimizationLevel: 'all',
        enableCpuMemArena: true,
        enableMemPattern: true,
      });

      // Load tokenizer (simplified - in practice, use a proper tokenizer)
      const fs = require('fs');
      if (fs.existsSync(tokenizerPath)) {
        this.tokenizer = JSON.parse(fs.readFileSync(tokenizerPath, 'utf8'));
      }

      this.isReady = true;
      console.log('ONNX model loaded successfully');
    } catch (error) {
      console.error('Failed to load ONNX model:', error);
      this.isReady = false;
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isReady || !this.session) {
      throw new Error('ONNX provider not ready');
    }

    try {
      // Tokenize input (simplified)
      const inputTokens = this.tokenize(prompt);
      const inputTensor = new ort.Tensor('int64', BigInt64Array.from(inputTokens.map(BigInt)), [1, inputTokens.length]);

      // Run inference
      const results = await this.session.run({
        input_ids: inputTensor,
      });

      // Decode output (simplified)
      const outputTokens = Array.from(results.logits.data as Float32Array);
      const generatedText = this.decode(outputTokens);

      const responseTime = performance.now() - startTime;

      return {
        content: generatedText,
        confidence: 0.85, // ONNX models typically have good confidence
        tokensUsed: inputTokens.length + outputTokens.length,
        responseTime,
        model: 'onnx-medical-llm',
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`ONNX inference failed: ${error}`);
    }
  }

  private tokenize(text: string): number[] {
    // Simplified tokenization - in practice, use proper tokenizer
    if (this.tokenizer && this.tokenizer.vocab) {
      return text.split(' ').map(word => this.tokenizer.vocab[word] || 0);
    }
    
    // Fallback: character-level tokenization
    return text.split('').map(char => char.charCodeAt(0));
  }

  private decode(tokens: number[]): string {
    // Simplified decoding - in practice, use proper decoder
    if (this.tokenizer && this.tokenizer.vocab) {
      const reverseVocab = Object.fromEntries(
        Object.entries(this.tokenizer.vocab).map(([k, v]) => [v, k])
      );
      return tokens.map(token => reverseVocab[token] || '').join(' ');
    }
    
    // Fallback: character-level decoding
    return String.fromCharCode(...tokens.slice(0, 100)); // Limit output
  }
}

// Export all local providers
export const localProviders = {
  OllamaProvider,
  HuggingFaceLocalProvider,
  ONNXProvider,
};
