/**
 * Cloud AI Providers for High-Performance EMR AI Engine
 * Optimized for scalability, advanced reasoning, and specialized models
 */

import { performance } from 'perf_hooks';
import OpenAI from 'openai';
import Groq from 'groq-sdk';
import Anthropic from '@anthropic-ai/sdk';
import { HfInference } from '@huggingface/inference';

interface AIProvider {
  name: string;
  type: 'local' | 'cloud';
  priority: number;
  costPerToken: number;
  avgResponseTime: number;
  maxTokens: number;
  isAvailable(): Promise<boolean>;
  generateResponse(prompt: string, options?: any): Promise<AIResponse>;
}

interface AIResponse {
  content: string;
  confidence: number;
  tokensUsed: number;
  responseTime: number;
  model: string;
  provider: string;
  cached: boolean;
}

/**
 * OpenAI Provider
 * Premium cloud AI with GPT-4 and specialized models
 */
export class OpenAIProvider implements AIProvider {
  name = 'openai';
  type: 'local' | 'cloud' = 'cloud';
  priority = 4; // Lower priority than local for privacy
  costPerToken = 0.00003; // GPT-4 pricing
  avgResponseTime = 800; // ms
  maxTokens = 128000; // GPT-4 Turbo

  private client: OpenAI;
  private availableModels: string[];
  private isHealthy = false;

  constructor(config: { apiKey: string; models: string[] }) {
    this.client = new OpenAI({
      apiKey: config.apiKey,
    });
    this.availableModels = config.models;
    this.checkHealth();
  }

  async isAvailable(): Promise<boolean> {
    return this.isHealthy;
  }

  private async checkHealth(): Promise<void> {
    try {
      const response = await this.client.models.list();
      this.isHealthy = response.data.length > 0;
    } catch (error) {
      this.isHealthy = false;
      console.warn('OpenAI not available:', error);
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isHealthy) {
      throw new Error('OpenAI provider not available');
    }

    const model = this.selectModel(options.requestType || 'general');
    
    try {
      const completion = await this.client.chat.completions.create({
        model,
        messages: [
          {
            role: 'system',
            content: options.systemPrompt || 'You are a helpful medical AI assistant specialized in EMR data processing. Provide accurate, evidence-based responses following medical best practices.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 1000,
        top_p: options.top_p || 0.9,
        frequency_penalty: 0,
        presence_penalty: 0,
      });

      const responseTime = performance.now() - startTime;
      const content = completion.choices[0]?.message?.content || '';

      return {
        content,
        confidence: this.calculateConfidence(completion),
        tokensUsed: completion.usage?.total_tokens || 0,
        responseTime,
        model,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`OpenAI generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    const modelMap: { [key: string]: string } = {
      'medical': 'gpt-4', // Best for complex medical reasoning
      'clinical': 'gpt-4', // Clinical decision support
      'summary': 'gpt-3.5-turbo', // Fast summarization
      'general': 'gpt-3.5-turbo', // General purpose
      'complex': 'gpt-4', // Complex reasoning tasks
    };

    return modelMap[requestType] || 'gpt-3.5-turbo';
  }

  private calculateConfidence(completion: any): number {
    const choice = completion.choices[0];
    
    // Base confidence on finish reason and response quality
    let confidence = 0.8;
    
    if (choice?.finish_reason === 'stop') confidence += 0.1;
    if (choice?.message?.content?.length > 100) confidence += 0.05;
    if (completion.usage?.total_tokens > 50) confidence += 0.05;
    
    return Math.min(confidence, 1.0);
  }
}

/**
 * Groq Provider
 * Ultra-fast inference with Llama and Mixtral models
 */
export class GroqProvider implements AIProvider {
  name = 'groq';
  type: 'local' | 'cloud' = 'cloud';
  priority = 5;
  costPerToken = 0.0000002; // Very cost-effective
  avgResponseTime = 200; // Ultra-fast inference
  maxTokens = 32768;

  private client: Groq;
  private availableModels: string[];
  private isHealthy = false;

  constructor(config: { apiKey: string; models: string[] }) {
    this.client = new Groq({
      apiKey: config.apiKey,
    });
    this.availableModels = config.models;
    this.checkHealth();
  }

  async isAvailable(): Promise<boolean> {
    return this.isHealthy;
  }

  private async checkHealth(): Promise<void> {
    try {
      const response = await this.client.models.list();
      this.isHealthy = response.data.length > 0;
    } catch (error) {
      this.isHealthy = false;
      console.warn('Groq not available:', error);
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isHealthy) {
      throw new Error('Groq provider not available');
    }

    const model = this.selectModel(options.requestType || 'general');
    
    try {
      const completion = await this.client.chat.completions.create({
        model,
        messages: [
          {
            role: 'system',
            content: options.systemPrompt || 'You are a medical AI assistant. Provide accurate, concise responses for EMR processing tasks.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: options.temperature || 0.7,
        max_tokens: options.max_tokens || 1000,
        top_p: options.top_p || 0.9,
      });

      const responseTime = performance.now() - startTime;
      const content = completion.choices[0]?.message?.content || '';

      return {
        content,
        confidence: this.calculateConfidence(completion),
        tokensUsed: completion.usage?.total_tokens || 0,
        responseTime,
        model,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`Groq generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    const modelMap: { [key: string]: string } = {
      'medical': 'llama3-70b-8192', // Best for medical tasks
      'fast': 'mixtral-8x7b-32768', // Fast general purpose
      'general': 'llama3-70b-8192', // Default choice
      'summary': 'mixtral-8x7b-32768', // Good for summarization
    };

    return modelMap[requestType] || 'llama3-70b-8192';
  }

  private calculateConfidence(completion: any): number {
    const choice = completion.choices[0];
    let confidence = 0.85; // Groq models are generally reliable
    
    if (choice?.finish_reason === 'stop') confidence += 0.1;
    if (choice?.message?.content?.length > 50) confidence += 0.05;
    
    return Math.min(confidence, 1.0);
  }
}

/**
 * Anthropic Provider
 * Claude models for advanced reasoning and safety
 */
export class AnthropicProvider implements AIProvider {
  name = 'anthropic';
  type: 'local' | 'cloud' = 'cloud';
  priority = 6;
  costPerToken = 0.000015; // Claude pricing
  avgResponseTime = 1200; // ms
  maxTokens = 200000; // Claude 3

  private client: Anthropic;
  private availableModels: string[];
  private isHealthy = false;

  constructor(config: { apiKey: string; models: string[] }) {
    this.client = new Anthropic({
      apiKey: config.apiKey,
    });
    this.availableModels = config.models;
    this.checkHealth();
  }

  async isAvailable(): Promise<boolean> {
    return this.isHealthy;
  }

  private async checkHealth(): Promise<void> {
    try {
      // Simple test to check if API key is valid
      this.isHealthy = true; // Assume healthy if API key is provided
    } catch (error) {
      this.isHealthy = false;
      console.warn('Anthropic not available:', error);
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isHealthy) {
      throw new Error('Anthropic provider not available');
    }

    const model = this.selectModel(options.requestType || 'general');
    
    try {
      const message = await this.client.messages.create({
        model,
        max_tokens: options.max_tokens || 1000,
        temperature: options.temperature || 0.7,
        system: options.systemPrompt || 'You are Claude, a helpful medical AI assistant specialized in EMR processing. Provide accurate, thoughtful responses.',
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      const responseTime = performance.now() - startTime;
      const content = message.content[0]?.type === 'text' ? message.content[0].text : '';

      return {
        content,
        confidence: this.calculateConfidence(message),
        tokensUsed: message.usage?.input_tokens + message.usage?.output_tokens || 0,
        responseTime,
        model,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`Anthropic generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    const modelMap: { [key: string]: string } = {
      'medical': 'claude-3-sonnet-20240229', // Best for medical reasoning
      'clinical': 'claude-3-sonnet-20240229', // Clinical tasks
      'fast': 'claude-3-haiku-20240307', // Fast responses
      'general': 'claude-3-sonnet-20240229', // Default
      'complex': 'claude-3-sonnet-20240229', // Complex reasoning
    };

    return modelMap[requestType] || 'claude-3-sonnet-20240229';
  }

  private calculateConfidence(message: any): number {
    let confidence = 0.9; // Claude models are highly reliable
    
    if (message.stop_reason === 'end_turn') confidence += 0.05;
    if (message.content?.[0]?.text?.length > 100) confidence += 0.05;
    
    return Math.min(confidence, 1.0);
  }
}

/**
 * Hugging Face Cloud Provider
 * Access to specialized medical models via Inference API
 */
export class HuggingFaceCloudProvider implements AIProvider {
  name = 'huggingface-cloud';
  type: 'local' | 'cloud' = 'cloud';
  priority = 7;
  costPerToken = 0.000001; // Very cost-effective
  avgResponseTime = 600; // ms
  maxTokens = 4096;

  private client: HfInference;
  private availableModels: string[];
  private isHealthy = false;

  constructor(config: { apiKey: string; models: string[] }) {
    this.client = new HfInference(config.apiKey);
    this.availableModels = config.models;
    this.checkHealth();
  }

  async isAvailable(): Promise<boolean> {
    return this.isHealthy;
  }

  private async checkHealth(): Promise<void> {
    try {
      // Test with a simple model
      await this.client.textGeneration({
        model: 'gpt2',
        inputs: 'test',
        parameters: { max_new_tokens: 1 },
      });
      this.isHealthy = true;
    } catch (error) {
      this.isHealthy = false;
      console.warn('Hugging Face Cloud not available:', error);
    }
  }

  async generateResponse(prompt: string, options: any = {}): Promise<AIResponse> {
    const startTime = performance.now();
    
    if (!this.isHealthy) {
      throw new Error('Hugging Face Cloud provider not available');
    }

    const model = this.selectModel(options.requestType || 'general');
    
    try {
      const result = await this.client.textGeneration({
        model,
        inputs: this.formatPrompt(prompt, options),
        parameters: {
          max_new_tokens: options.max_tokens || 200,
          temperature: options.temperature || 0.7,
          top_p: options.top_p || 0.9,
          do_sample: true,
          return_full_text: false,
        },
      });

      const responseTime = performance.now() - startTime;
      const content = result.generated_text || '';

      return {
        content,
        confidence: this.calculateConfidence(result),
        tokensUsed: this.estimateTokens(prompt + content),
        responseTime,
        model,
        provider: this.name,
        cached: false,
      };
    } catch (error) {
      throw new Error(`Hugging Face generation failed: ${error}`);
    }
  }

  private selectModel(requestType: string): string {
    const modelMap: { [key: string]: string } = {
      'medical': 'microsoft/BioGPT-Large',
      'clinical': 'microsoft/BioGPT-Large',
      'general': 'google/flan-t5-large',
      'summary': 'facebook/bart-large-cnn',
    };

    return modelMap[requestType] || 'microsoft/BioGPT-Large';
  }

  private formatPrompt(prompt: string, options: any): string {
    const systemPrompt = options.systemPrompt || 
      'You are a medical AI assistant. Provide accurate responses for healthcare applications.';
    
    return `${systemPrompt}\n\nQuery: ${prompt}\n\nResponse:`;
  }

  private calculateConfidence(result: any): number {
    // Base confidence for HF models
    let confidence = 0.75;
    
    if (result.generated_text?.length > 50) confidence += 0.1;
    if (result.generated_text?.includes('.')) confidence += 0.05; // Complete sentences
    
    return Math.min(confidence, 0.95);
  }

  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }
}

// Export all cloud providers
export const cloudProviders = {
  OpenAIProvider,
  GroqProvider,
  AnthropicProvider,
  HuggingFaceCloudProvider,
};
