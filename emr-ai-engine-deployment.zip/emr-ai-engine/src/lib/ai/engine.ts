/**
 * High-Performance EMR AI Engine
 * Hybrid Local/Cloud Architecture with Intelligent Model Selection
 */

import { LRUCache } from 'lru-cache';
import { performance } from 'perf_hooks';
import { EventEmitter } from 'events';

// AI Provider Interfaces
interface AIProvider {
  name: string;
  type: 'local' | 'cloud';
  priority: number;
  costPerToken: number;
  avgResponseTime: number;
  maxTokens: number;
  isAvailable(): Promise<boolean>;
  generateResponse(prompt: string, options?: any): Promise<AIResponse>;
}

interface AIResponse {
  content: string;
  confidence: number;
  tokensUsed: number;
  responseTime: number;
  model: string;
  provider: string;
  cached: boolean;
}

interface ModelConfig {
  name: string;
  provider: string;
  type: 'local' | 'cloud';
  specialization: string[];
  maxTokens: number;
  temperature: number;
  enabled: boolean;
}

interface PerformanceMetrics {
  totalRequests: number;
  avgResponseTime: number;
  cacheHitRate: number;
  errorRate: number;
  tokensProcessed: number;
  costSaved: number;
}

class EMRAIEngine extends EventEmitter {
  private providers: Map<string, AIProvider> = new Map();
  private cache: LRUCache<string, AIResponse>;
  private metrics: PerformanceMetrics;
  private isLocal: boolean;
  private isCloud: boolean;

  constructor() {
    super();
    
    // Initialize cache with performance optimizations
    this.cache = new LRUCache({
      max: 10000, // Maximum 10k cached responses
      ttl: 1000 * 60 * 30, // 30 minutes TTL
      updateAgeOnGet: true,
      allowStale: true,
    });

    // Initialize metrics
    this.metrics = {
      totalRequests: 0,
      avgResponseTime: 0,
      cacheHitRate: 0,
      errorRate: 0,
      tokensProcessed: 0,
      costSaved: 0,
    };

    // Determine deployment mode
    this.isLocal = process.env.LOCAL_MODE === 'true';
    this.isCloud = process.env.CLOUD_MODE === 'true';

    // Initialize providers based on mode
    this.initializeProviders();
    
    // Start performance monitoring
    this.startPerformanceMonitoring();
  }

  private async initializeProviders() {
    try {
      // Local providers (always available in local mode)
      if (this.isLocal || !this.isCloud) {
        await this.registerLocalProviders();
      }

      // Cloud providers (available in cloud mode or as fallback)
      if (this.isCloud || !this.isLocal) {
        await this.registerCloudProviders();
      }

      this.emit('providers-initialized', {
        local: this.getProvidersByType('local').length,
        cloud: this.getProvidersByType('cloud').length,
      });
    } catch (error) {
      this.emit('initialization-error', error);
      throw new Error(`Failed to initialize AI providers: ${error}`);
    }
  }

  private async registerLocalProviders() {
    // Ollama Local Provider
    const ollamaProvider = new OllamaProvider({
      baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
      models: ['llama3.2:3b', 'phi3.5:mini', 'biogpt:base'],
    });

    if (await ollamaProvider.isAvailable()) {
      this.providers.set('ollama', ollamaProvider);
    }

    // Hugging Face Transformers (Local)
    const hfLocalProvider = new HuggingFaceLocalProvider({
      models: [
        'microsoft/DialoGPT-medium',
        'microsoft/BioGPT',
        'emilyalsentzer/Bio_ClinicalBERT',
      ],
    });

    if (await hfLocalProvider.isAvailable()) {
      this.providers.set('huggingface-local', hfLocalProvider);
    }

    // ONNX Runtime Provider
    const onnxProvider = new ONNXProvider({
      modelPath: './models/medical-llm.onnx',
      tokenizerPath: './models/tokenizer.json',
    });

    if (await onnxProvider.isAvailable()) {
      this.providers.set('onnx', onnxProvider);
    }
  }

  private async registerCloudProviders() {
    // OpenAI Provider
    if (process.env.OPENAI_API_KEY) {
      const openaiProvider = new OpenAIProvider({
        apiKey: process.env.OPENAI_API_KEY,
        models: ['gpt-4', 'gpt-3.5-turbo'],
      });
      this.providers.set('openai', openaiProvider);
    }

    // Groq Provider
    if (process.env.GROQ_API_KEY) {
      const groqProvider = new GroqProvider({
        apiKey: process.env.GROQ_API_KEY,
        models: ['llama3-70b-8192', 'mixtral-8x7b-32768'],
      });
      this.providers.set('groq', groqProvider);
    }

    // Anthropic Provider
    if (process.env.ANTHROPIC_API_KEY) {
      const anthropicProvider = new AnthropicProvider({
        apiKey: process.env.ANTHROPIC_API_KEY,
        models: ['claude-3-sonnet-20240229', 'claude-3-haiku-20240307'],
      });
      this.providers.set('anthropic', anthropicProvider);
    }

    // Hugging Face Inference API
    if (process.env.HUGGINGFACE_API_KEY) {
      const hfCloudProvider = new HuggingFaceCloudProvider({
        apiKey: process.env.HUGGINGFACE_API_KEY,
        models: [
          'microsoft/DialoGPT-large',
          'microsoft/BioGPT-Large',
          'google/flan-t5-large',
        ],
      });
      this.providers.set('huggingface-cloud', hfCloudProvider);
    }
  }

  /**
   * Intelligent model selection based on request characteristics
   */
  private selectOptimalProvider(
    requestType: string,
    complexity: number,
    urgency: 'low' | 'medium' | 'high',
    dataPrivacy: 'standard' | 'sensitive' | 'critical'
  ): AIProvider | null {
    const availableProviders = Array.from(this.providers.values())
      .filter(provider => provider.isAvailable());

    if (availableProviders.length === 0) {
      return null;
    }

    // Privacy-first selection
    if (dataPrivacy === 'critical') {
      const localProviders = availableProviders.filter(p => p.type === 'local');
      if (localProviders.length > 0) {
        return this.selectByPerformance(localProviders, urgency);
      }
    }

    // Performance-first selection for high urgency
    if (urgency === 'high') {
      return this.selectByResponseTime(availableProviders);
    }

    // Cost-optimized selection for low urgency
    if (urgency === 'low') {
      return this.selectByCost(availableProviders);
    }

    // Balanced selection for medium urgency
    return this.selectBalanced(availableProviders, complexity);
  }

  private selectByPerformance(providers: AIProvider[], urgency: string): AIProvider {
    return providers.reduce((best, current) => 
      current.avgResponseTime < best.avgResponseTime ? current : best
    );
  }

  private selectByResponseTime(providers: AIProvider[]): AIProvider {
    return providers.reduce((fastest, current) => 
      current.avgResponseTime < fastest.avgResponseTime ? current : fastest
    );
  }

  private selectByCost(providers: AIProvider[]): AIProvider {
    return providers.reduce((cheapest, current) => 
      current.costPerToken < cheapest.costPerToken ? current : cheapest
    );
  }

  private selectBalanced(providers: AIProvider[], complexity: number): AIProvider {
    // Score based on response time, cost, and capability
    return providers.reduce((best, current) => {
      const currentScore = this.calculateProviderScore(current, complexity);
      const bestScore = this.calculateProviderScore(best, complexity);
      return currentScore > bestScore ? current : best;
    });
  }

  private calculateProviderScore(provider: AIProvider, complexity: number): number {
    const responseTimeScore = 1000 / provider.avgResponseTime; // Higher is better
    const costScore = 1 / (provider.costPerToken + 0.001); // Higher is better
    const capabilityScore = provider.maxTokens / 1000; // Higher is better
    
    return (responseTimeScore * 0.4) + (costScore * 0.3) + (capabilityScore * 0.3);
  }

  /**
   * Main AI processing method with caching and fallback
   */
  async processRequest(
    prompt: string,
    options: {
      requestType?: string;
      complexity?: number;
      urgency?: 'low' | 'medium' | 'high';
      dataPrivacy?: 'standard' | 'sensitive' | 'critical';
      useCache?: boolean;
      maxRetries?: number;
    } = {}
  ): Promise<AIResponse> {
    const startTime = performance.now();
    const cacheKey = this.generateCacheKey(prompt, options);
    
    // Check cache first
    if (options.useCache !== false) {
      const cachedResponse = this.cache.get(cacheKey);
      if (cachedResponse) {
        this.updateMetrics('cache-hit', performance.now() - startTime);
        return { ...cachedResponse, cached: true };
      }
    }

    // Select optimal provider
    const provider = this.selectOptimalProvider(
      options.requestType || 'general',
      options.complexity || 0.5,
      options.urgency || 'medium',
      options.dataPrivacy || 'standard'
    );

    if (!provider) {
      throw new Error('No available AI providers');
    }

    try {
      // Generate response
      const response = await provider.generateResponse(prompt, options);
      response.cached = false;
      
      // Cache the response
      if (options.useCache !== false) {
        this.cache.set(cacheKey, response);
      }

      // Update metrics
      this.updateMetrics('success', performance.now() - startTime, response);
      
      return response;
    } catch (error) {
      // Implement fallback logic
      return this.handleProviderFailure(prompt, options, provider, error, startTime);
    }
  }

  private async handleProviderFailure(
    prompt: string,
    options: any,
    failedProvider: AIProvider,
    error: any,
    startTime: number
  ): Promise<AIResponse> {
    this.emit('provider-error', { provider: failedProvider.name, error });
    
    // Try fallback providers
    const fallbackProviders = Array.from(this.providers.values())
      .filter(p => p !== failedProvider && p.isAvailable())
      .sort((a, b) => a.priority - b.priority);

    for (const fallbackProvider of fallbackProviders) {
      try {
        const response = await fallbackProvider.generateResponse(prompt, options);
        response.cached = false;
        
        this.updateMetrics('fallback-success', performance.now() - startTime, response);
        return response;
      } catch (fallbackError) {
        this.emit('fallback-error', { 
          provider: fallbackProvider.name, 
          error: fallbackError 
        });
        continue;
      }
    }

    // All providers failed
    this.updateMetrics('error', performance.now() - startTime);
    throw new Error(`All AI providers failed. Last error: ${error.message}`);
  }

  private generateCacheKey(prompt: string, options: any): string {
    const hash = require('crypto')
      .createHash('sha256')
      .update(JSON.stringify({ prompt, options }))
      .digest('hex');
    return hash.substring(0, 16);
  }

  private updateMetrics(
    type: 'success' | 'cache-hit' | 'fallback-success' | 'error',
    responseTime: number,
    response?: AIResponse
  ) {
    this.metrics.totalRequests++;
    
    // Update average response time
    this.metrics.avgResponseTime = 
      (this.metrics.avgResponseTime * (this.metrics.totalRequests - 1) + responseTime) / 
      this.metrics.totalRequests;

    if (type === 'cache-hit') {
      this.metrics.cacheHitRate = 
        (this.metrics.cacheHitRate * (this.metrics.totalRequests - 1) + 1) / 
        this.metrics.totalRequests;
    }

    if (type === 'error') {
      this.metrics.errorRate = 
        (this.metrics.errorRate * (this.metrics.totalRequests - 1) + 1) / 
        this.metrics.totalRequests;
    }

    if (response) {
      this.metrics.tokensProcessed += response.tokensUsed;
    }
  }

  private startPerformanceMonitoring() {
    // Emit metrics every 30 seconds
    setInterval(() => {
      this.emit('metrics-update', this.getMetrics());
    }, 30000);

    // Clean up cache periodically
    setInterval(() => {
      this.cache.purgeStale();
    }, 300000); // 5 minutes
  }

  // Public API methods
  getMetrics(): PerformanceMetrics {
    return { ...this.metrics };
  }

  getProvidersByType(type: 'local' | 'cloud'): AIProvider[] {
    return Array.from(this.providers.values()).filter(p => p.type === type);
  }

  async healthCheck(): Promise<{ [key: string]: boolean }> {
    const health: { [key: string]: boolean } = {};
    
    for (const [name, provider] of this.providers) {
      health[name] = await provider.isAvailable();
    }
    
    return health;
  }

  clearCache(): void {
    this.cache.clear();
  }

  getProviderStatus(): { [key: string]: any } {
    const status: { [key: string]: any } = {};
    
    for (const [name, provider] of this.providers) {
      status[name] = {
        type: provider.type,
        priority: provider.priority,
        avgResponseTime: provider.avgResponseTime,
        costPerToken: provider.costPerToken,
        maxTokens: provider.maxTokens,
      };
    }
    
    return status;
  }
}

// Export singleton instance
export const aiEngine = new EMRAIEngine();
export default aiEngine;
