import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import { Toaster } from "react-hot-toast";
import "./globals.css";

const inter = Inter({ 
  subsets: ["latin"],
  display: 'swap',
  preload: true,
});

export const metadata: Metadata = {
  title: "EMR AI Engine - Intelligent Medical Record Assistant",
  description: "High-performance AI API engine for Electronic Medical Records with local and cloud capabilities, HIPAA compliance, and comprehensive medical AI modules.",
  keywords: [
    "EMR", "AI", "Medical", "Healthcare", "API", "HIPAA", "Clinical",
    "Electronic Medical Records", "Machine Learning", "NLP", "Performance",
    "Local AI", "Cloud AI", "Hugging Face", "Training Academy"
  ],
  authors: [{ name: "GreyBrain AI" }],
  creator: "GreyBrain AI",
  publisher: "GreyBrain AI",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://emr-ai-engine.com',
    title: 'EMR AI Engine - Intelligent Medical Record Assistant',
    description: 'High-performance AI API engine for Electronic Medical Records',
    siteName: 'EMR AI Engine',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'EMR AI Engine - Intelligent Medical Record Assistant',
    description: 'High-performance AI API engine for Electronic Medical Records',
    creator: '@greybrainai',
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' },
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider
      publishableKey={process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY}
      appearance={{
        baseTheme: undefined,
        variables: {
          colorPrimary: '#2563eb',
          colorBackground: '#ffffff',
          colorInputBackground: '#f8fafc',
          colorInputText: '#1e293b',
          borderRadius: '0.5rem',
        },
        elements: {
          formButtonPrimary: 'bg-blue-600 hover:bg-blue-700 text-white',
          card: 'shadow-xl border border-gray-200',
          headerTitle: 'text-gray-900 font-semibold',
          headerSubtitle: 'text-gray-600',
        },
      }}
    >
      <html lang="en" className={inter.className}>
        <head>
          {/* Performance optimizations */}
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
          <link rel="dns-prefetch" href="//api.openai.com" />
          <link rel="dns-prefetch" href="//api.groq.com" />
          <link rel="dns-prefetch" href="//huggingface.co" />
          
          {/* PWA support */}
          <link rel="manifest" href="/manifest.json" />
          <meta name="theme-color" content="#2563eb" />
          <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png" />
          
          {/* Security headers */}
          <meta httpEquiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-eval' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' https://fonts.gstatic.com; connect-src 'self' https://api.clerk.com https://api.openai.com https://api.groq.com https://huggingface.co;" />
        </head>
        <body className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 antialiased">
          {/* Performance monitoring */}
          {process.env.NODE_ENV === 'production' && (
            <script
              dangerouslySetInnerHTML={{
                __html: `
                  // Performance monitoring
                  window.addEventListener('load', function() {
                    if ('performance' in window) {
                      const perfData = performance.getEntriesByType('navigation')[0];
                      console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
                    }
                  });
                `,
              }}
            />
          )}
          
          {/* Main application */}
          <div className="flex min-h-screen flex-col">
            {/* Header */}
            <header className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white/80 backdrop-blur-sm">
              <div className="container mx-auto px-4">
                <div className="flex h-16 items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <div className="h-8 w-8 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">EMR</span>
                      </div>
                      <div>
                        <h1 className="text-xl font-bold text-gray-900">EMR AI Engine</h1>
                        <p className="text-xs text-gray-500">Intelligent Medical Assistant</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Performance indicator */}
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <div className="h-2 w-2 rounded-full bg-green-500"></div>
                      <span>
                        {process.env.LOCAL_MODE === 'true' ? 'Local Mode' : 'Cloud Mode'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </header>

            {/* Main content */}
            <main className="flex-1">
              {children}
            </main>

            {/* Footer */}
            <footer className="border-t border-gray-200 bg-white">
              <div className="container mx-auto px-4 py-6">
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <div>
                    <p>&copy; 2024 EMR AI Engine by GreyBrain AI. All rights reserved.</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span>HIPAA Compliant</span>
                    <span>•</span>
                    <span>High Performance</span>
                    <span>•</span>
                    <span>Local & Cloud</span>
                  </div>
                </div>
              </div>
            </footer>
          </div>

          {/* Toast notifications */}
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#ffffff',
                color: '#1f2937',
                border: '1px solid #e5e7eb',
                borderRadius: '0.5rem',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
              },
              success: {
                iconTheme: {
                  primary: '#10b981',
                  secondary: '#ffffff',
                },
              },
              error: {
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#ffffff',
                },
              },
            }}
          />
        </body>
      </html>
    </ClerkProvider>
  );
}
