'use client';

import { useState, useEffect } from 'react';
import { useUser } from '@clerk/nextjs';
import Link from 'next/link';
import { 
  ChartBarIcon,
  CpuChipIcon,
  CloudIcon,
  BoltIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  ClockIcon,
  ServerIcon,
  BeakerIcon,
  DocumentTextIcon,
  UserGroupIcon,
  AcademicCapIcon,
  ArrowUpIcon,
  ArrowDownIcon
} from '@heroicons/react/24/outline';

interface DashboardMetrics {
  performance: {
    avgResponseTime: number;
    throughput: number;
    cacheHitRate: number;
    errorRate: number;
    uptime: number;
  };
  usage: {
    totalRequests: number;
    requestsToday: number;
    tokensProcessed: number;
    costSaved: number;
  };
  models: {
    activeModels: number;
    localModels: number;
    cloudModels: number;
    modelHealth: { [key: string]: boolean };
  };
  modules: {
    historyTaking: { requests: number; avgTime: number; accuracy: number };
    dischargeSummary: { requests: number; avgTime: number; accuracy: number };
    imageAnalysis: { requests: number; avgTime: number; accuracy: number };
    medicationReconciliation: { requests: number; avgTime: number; accuracy: number };
    clinicalDecision: { requests: number; avgTime: number; accuracy: number };
    progressNotes: { requests: number; avgTime: number; accuracy: number };
  };
}

export default function DashboardPage() {
  const { isSignedIn, user } = useUser();
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTimeRange, setSelectedTimeRange] = useState('24h');
  const [realTimeUpdates, setRealTimeUpdates] = useState(true);

  useEffect(() => {
    loadDashboardMetrics();
    
    // Set up real-time updates
    if (realTimeUpdates) {
      const interval = setInterval(loadDashboardMetrics, 30000); // Update every 30 seconds
      return () => clearInterval(interval);
    }
  }, [selectedTimeRange, realTimeUpdates]);

  const loadDashboardMetrics = async () => {
    try {
      setIsLoading(true);
      
      // Simulate API call to get real metrics
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockMetrics: DashboardMetrics = {
        performance: {
          avgResponseTime: Math.floor(Math.random() * 50) + 80, // 80-130ms
          throughput: Math.floor(Math.random() * 500) + 800, // 800-1300 req/min
          cacheHitRate: Math.floor(Math.random() * 15) + 85, // 85-100%
          errorRate: Math.random() * 0.5, // 0-0.5%
          uptime: 99.9
        },
        usage: {
          totalRequests: 156420,
          requestsToday: Math.floor(Math.random() * 1000) + 2500,
          tokensProcessed: 45680000,
          costSaved: 1247.50
        },
        models: {
          activeModels: 12,
          localModels: 5,
          cloudModels: 7,
          modelHealth: {
            'ollama': true,
            'huggingface-local': true,
            'onnx': true,
            'openai': true,
            'groq': true,
            'anthropic': true,
            'huggingface-cloud': true
          }
        },
        modules: {
          historyTaking: { 
            requests: Math.floor(Math.random() * 500) + 1200, 
            avgTime: Math.floor(Math.random() * 30) + 120, 
            accuracy: 94.2 
          },
          dischargeSummary: { 
            requests: Math.floor(Math.random() * 300) + 800, 
            avgTime: Math.floor(Math.random() * 50) + 180, 
            accuracy: 96.8 
          },
          imageAnalysis: { 
            requests: Math.floor(Math.random() * 200) + 600, 
            avgTime: Math.floor(Math.random() * 100) + 400, 
            accuracy: 91.5 
          },
          medicationReconciliation: { 
            requests: Math.floor(Math.random() * 400) + 1000, 
            avgTime: Math.floor(Math.random() * 20) + 35, 
            accuracy: 98.1 
          },
          clinicalDecision: { 
            requests: Math.floor(Math.random() * 250) + 700, 
            avgTime: Math.floor(Math.random() * 40) + 120, 
            accuracy: 92.7 
          },
          progressNotes: { 
            requests: Math.floor(Math.random() * 350) + 900, 
            avgTime: Math.floor(Math.random() * 25) + 65, 
            accuracy: 95.3 
          }
        }
      };
      
      setMetrics(mockMetrics);
    } catch (error) {
      console.error('Failed to load dashboard metrics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isSignedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Authentication Required</h1>
          <p className="text-gray-600 mb-6">Please sign in to access the dashboard.</p>
          <Link
            href="/sign-in"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading || !metrics) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (value: number, thresholds: { good: number; warning: number }) => {
    if (value >= thresholds.good) return 'text-green-600';
    if (value >= thresholds.warning) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = (value: number, thresholds: { good: number; warning: number }) => {
    if (value >= thresholds.good) return CheckCircleIcon;
    if (value >= thresholds.warning) return ExclamationTriangleIcon;
    return ExclamationTriangleIcon;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">EMR AI Dashboard</h1>
              <p className="mt-1 text-gray-600">
                Welcome back, {user?.firstName || 'User'}! Monitor your AI engine performance.
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Real-time updates:</label>
                <button
                  onClick={() => setRealTimeUpdates(!realTimeUpdates)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    realTimeUpdates ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      realTimeUpdates ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <select
                value={selectedTimeRange}
                onChange={(e) => setSelectedTimeRange(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
              >
                <option value="1h">Last Hour</option>
                <option value="24h">Last 24 Hours</option>
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Performance Overview */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Response Time</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.performance.avgResponseTime}ms</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <ArrowDownIcon className="h-3 w-3 mr-1" />
                    12% faster
                  </p>
                </div>
                <BoltIcon className="h-8 w-8 text-yellow-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Throughput</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.performance.throughput}/min</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <ArrowUpIcon className="h-3 w-3 mr-1" />
                    8% increase
                  </p>
                </div>
                <ChartBarIcon className="h-8 w-8 text-blue-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Cache Hit Rate</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.performance.cacheHitRate}%</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <ArrowUpIcon className="h-3 w-3 mr-1" />
                    3% improvement
                  </p>
                </div>
                <ServerIcon className="h-8 w-8 text-purple-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Error Rate</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.performance.errorRate.toFixed(2)}%</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <ArrowDownIcon className="h-3 w-3 mr-1" />
                    0.1% decrease
                  </p>
                </div>
                <CheckCircleIcon className="h-8 w-8 text-green-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Uptime</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.performance.uptime}%</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <CheckCircleIcon className="h-3 w-3 mr-1" />
                    Excellent
                  </p>
                </div>
                <ClockIcon className="h-8 w-8 text-emerald-500" />
              </div>
            </div>
          </div>
        </div>

        {/* Usage Statistics */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Usage Statistics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Requests</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.usage.totalRequests.toLocaleString()}</p>
                </div>
                <UserGroupIcon className="h-8 w-8 text-blue-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Requests Today</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.usage.requestsToday.toLocaleString()}</p>
                </div>
                <ChartBarIcon className="h-8 w-8 text-green-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Tokens Processed</p>
                  <p className="text-2xl font-bold text-gray-900">{(metrics.usage.tokensProcessed / 1000000).toFixed(1)}M</p>
                </div>
                <CpuChipIcon className="h-8 w-8 text-purple-500" />
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Cost Saved</p>
                  <p className="text-2xl font-bold text-gray-900">${metrics.usage.costSaved.toFixed(2)}</p>
                </div>
                <BoltIcon className="h-8 w-8 text-yellow-500" />
              </div>
            </div>
          </div>
        </div>

        {/* AI Modules Performance */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Modules Performance</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Object.entries(metrics.modules).map(([moduleName, moduleData]) => {
              const StatusIcon = getStatusIcon(moduleData.accuracy, { good: 95, warning: 90 });
              const statusColor = getStatusColor(moduleData.accuracy, { good: 95, warning: 90 });
              
              return (
                <div key={moduleName} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 capitalize">
                      {moduleName.replace(/([A-Z])/g, ' $1').trim()}
                    </h3>
                    <StatusIcon className={`h-6 w-6 ${statusColor}`} />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Requests</p>
                      <p className="text-xl font-bold text-gray-900">{moduleData.requests.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Avg Time</p>
                      <p className="text-xl font-bold text-gray-900">{moduleData.avgTime}ms</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Accuracy</p>
                      <p className={`text-xl font-bold ${statusColor}`}>{moduleData.accuracy}%</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Model Health Status */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Model Health Status</h2>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-sm text-gray-500">Active Models</p>
                <p className="text-3xl font-bold text-gray-900">{metrics.models.activeModels}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Local Models</p>
                <p className="text-3xl font-bold text-blue-600">{metrics.models.localModels}</p>
                <CpuChipIcon className="h-6 w-6 text-blue-600 mx-auto mt-1" />
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Cloud Models</p>
                <p className="text-3xl font-bold text-purple-600">{metrics.models.cloudModels}</p>
                <CloudIcon className="h-6 w-6 text-purple-600 mx-auto mt-1" />
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-500">Health Score</p>
                <p className="text-3xl font-bold text-green-600">
                  {Math.round((Object.values(metrics.models.modelHealth).filter(Boolean).length / Object.keys(metrics.models.modelHealth).length) * 100)}%
                </p>
                <CheckCircleIcon className="h-6 w-6 text-green-600 mx-auto mt-1" />
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-3">Provider Status</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                {Object.entries(metrics.models.modelHealth).map(([provider, isHealthy]) => (
                  <div key={provider} className="flex items-center space-x-2">
                    <div className={`h-3 w-3 rounded-full ${isHealthy ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-sm text-gray-700 capitalize">{provider}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link
              href="/api-docs"
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow group"
            >
              <DocumentTextIcon className="h-8 w-8 text-blue-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600">API Documentation</h3>
              <p className="text-gray-600 text-sm">View comprehensive API docs</p>
            </Link>

            <Link
              href="/training-academy"
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow group"
            >
              <AcademicCapIcon className="h-8 w-8 text-purple-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-purple-600">Training Academy</h3>
              <p className="text-gray-600 text-sm">Learn AI model integration</p>
            </Link>

            <Link
              href="/performance"
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow group"
            >
              <ChartBarIcon className="h-8 w-8 text-green-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-green-600">Performance Analytics</h3>
              <p className="text-gray-600 text-sm">Detailed performance metrics</p>
            </Link>

            <Link
              href="/settings"
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow group"
            >
              <CpuChipIcon className="h-8 w-8 text-orange-600 mb-3" />
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-orange-600">Model Configuration</h3>
              <p className="text-gray-600 text-sm">Configure AI models and providers</p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
