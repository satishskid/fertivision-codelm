import type { NextConfig } from "next";

const isLocal = process.env.LOCAL_MODE === 'true';
const isCloud = process.env.CLOUD_MODE === 'true';

const nextConfig: NextConfig = {
  // Performance optimizations
  experimental: {
    optimizeCss: true,
    optimizePackageImports: ['@heroicons/react', 'lucide-react'],
    turbo: {
      rules: {
        '*.svg': {
          loaders: ['@svgr/webpack'],
          as: '*.js',
        },
      },
    },
  },

  // Compiler optimizations
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
  },

  // Image optimization
  images: {
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    unoptimized: isLocal, // Disable optimization for local mode
  },

  // Headers for performance and security
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
      {
        source: '/api/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'no-store, max-age=0',
          },
        ],
      },
      {
        source: '/static/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
    ];
  },

  // Webpack optimizations
  webpack: (config, { dev, isServer }) => {
    // Performance optimizations
    if (!dev) {
      config.optimization.splitChunks = {
        chunks: 'all',
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'all',
          },
          ai: {
            test: /[\\/]node_modules[\\/](@huggingface|@xenova|onnxruntime|langchain)[\\/]/,
            name: 'ai-libs',
            chunks: 'all',
            priority: 10,
          },
        },
      };
    }

    // Handle ONNX files
    config.module.rules.push({
      test: /\.onnx$/,
      use: 'file-loader',
    });

    // Handle WebAssembly
    config.experiments = {
      ...config.experiments,
      asyncWebAssembly: true,
    };

    // Optimize for local vs cloud
    if (isLocal) {
      config.resolve.alias = {
        ...config.resolve.alias,
        '@ai/local': require.resolve('./src/lib/ai/local'),
      };
    } else if (isCloud) {
      config.resolve.alias = {
        ...config.resolve.alias,
        '@ai/cloud': require.resolve('./src/lib/ai/cloud'),
      };
    }

    return config;
  },

  // Environment-specific configurations
  env: {
    LOCAL_MODE: isLocal ? 'true' : 'false',
    CLOUD_MODE: isCloud ? 'true' : 'false',
    PERFORMANCE_MODE: 'optimized',
  },

  // TypeScript configuration
  typescript: {
    ignoreBuildErrors: false,
  },

  // ESLint configuration
  eslint: {
    ignoreDuringBuilds: false,
  },

  // Output configuration
  output: isLocal ? 'standalone' : undefined,

  // Compression
  compress: true,

  // Power optimizations
  poweredByHeader: false,
  
  // Redirect configuration
  async redirects() {
    return [
      {
        source: '/docs',
        destination: '/api-docs',
        permanent: true,
      },
      {
        source: '/training',
        destination: '/training-academy',
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
