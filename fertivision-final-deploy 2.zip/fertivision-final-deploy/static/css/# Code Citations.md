# Code Citations

## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'

```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'

```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER']
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER']
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER']
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] =
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] =
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] =
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UP
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UP
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UP
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/',
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/',
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/',
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():

```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():

```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():

```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
   
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
   
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
   
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload',
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload',
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload',
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():

```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():

```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():

```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
   
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
   
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
   
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file =
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file =
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file =
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request
```


## License: unknown
https://github.com/Oliver0804/Python-Image-Classifier-with-RESTful-API/blob/6566bce908df9c37cd262cf050d9a34ba87ba348/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.
```


## License: unknown
https://github.com/CatalinIuga/SudoOCR/blob/658046ebee3680d3a163c6977ec96cf0be3f335e/flask/main.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.
```


## License: unknown
https://github.com/leomarzeuski/lepanto/blob/3ab8f3e18d34a7752664664382c17b774164a5df/app.py

```
'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.
```

