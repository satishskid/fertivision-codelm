// Real Razorpay Integration for FertiVision Cloud SaaS
import Razorpay from 'razorpay';
import crypto from 'crypto';

// Subscription plans configuration
export const SUBSCRIPTION_PLANS = {
  free: {
    id: 'plan_free',
    name: 'Free',
    price: 0,
    currency: 'INR',
    interval: 'monthly',
    analyses_limit: 10,
    features: [
      '10 analyses per month',
      'Basic support',
      'Standard processing time',
      'Community access'
    ]
  },
  professional: {
    id: 'plan_professional',
    name: 'Professional',
    price: 299900, // ₹2,999 in paise
    currency: 'INR',
    interval: 'monthly',
    analyses_limit: 500,
    features: [
      '500 analyses per month',
      'Priority support',
      'Faster processing',
      'API access',
      'Custom integrations',
      'Advanced reporting'
    ]
  },
  enterprise: {
    id: 'plan_enterprise',
    name: 'Enterprise',
    price: 999900, // ₹9,999 in paise
    currency: 'INR',
    interval: 'monthly',
    analyses_limit: -1, // Unlimited
    features: [
      'Unlimited analyses',
      '24/7 support',
      'Dedicated infrastructure',
      'White-label options',
      'Custom AI models',
      'SLA guarantees',
      'Dedicated account manager'
    ]
  }
};

// Initialize Razorpay instance
function getRazorpayInstance() {
  const keyId = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  
  if (!keyId || !keySecret) {
    throw new Error('Razorpay credentials not configured');
  }
  
  return new Razorpay({
    key_id: keyId,
    key_secret: keySecret,
  });
}

// Create Razorpay customer
export async function createCustomer(email: string, name: string, phone?: string) {
  try {
    const razorpay = getRazorpayInstance();
    
    const customer = await razorpay.customers.create({
      name,
      email,
      contact: phone,
      notes: {
        created_via: 'FertiVision Cloud SaaS',
        created_at: new Date().toISOString()
      }
    });
    
    return customer;
  } catch (error) {
    console.error('Error creating Razorpay customer:', error);
    throw error;
  }
}

// Create subscription plan in Razorpay
export async function createSubscriptionPlan(planId: string) {
  try {
    const razorpay = getRazorpayInstance();
    const plan = SUBSCRIPTION_PLANS[planId as keyof typeof SUBSCRIPTION_PLANS];
    
    if (!plan) {
      throw new Error(`Invalid plan ID: ${planId}`);
    }
    
    // Skip creating free plan in Razorpay
    if (plan.price === 0) {
      return { id: plan.id, ...plan };
    }
    
    const razorpayPlan = await razorpay.plans.create({
      period: plan.interval,
      interval: 1,
      item: {
        name: `FertiVision ${plan.name} Plan`,
        amount: plan.price,
        currency: plan.currency,
        description: `${plan.analyses_limit === -1 ? 'Unlimited' : plan.analyses_limit} analyses per month`
      },
      notes: {
        plan_type: planId,
        analyses_limit: plan.analyses_limit.toString(),
        created_via: 'FertiVision Cloud SaaS'
      }
    });
    
    return razorpayPlan;
  } catch (error) {
    console.error('Error creating subscription plan:', error);
    throw error;
  }
}

// Create subscription
export async function createSubscription(
  planId: string,
  customerId: string,
  totalCount: number = 12 // 12 months
) {
  try {
    const razorpay = getRazorpayInstance();
    const plan = SUBSCRIPTION_PLANS[planId as keyof typeof SUBSCRIPTION_PLANS];
    
    if (!plan) {
      throw new Error(`Invalid plan ID: ${planId}`);
    }
    
    // Handle free plan separately
    if (plan.price === 0) {
      return {
        id: `sub_free_${Date.now()}`,
        plan_id: plan.id,
        customer_id: customerId,
        status: 'active',
        current_start: Math.floor(Date.now() / 1000),
        current_end: Math.floor((Date.now() + 30 * 24 * 60 * 60 * 1000) / 1000), // 30 days
        created_at: Math.floor(Date.now() / 1000)
      };
    }
    
    const subscription = await razorpay.subscriptions.create({
      plan_id: plan.id,
      customer_notify: 1,
      total_count: totalCount,
      notes: {
        customer_id: customerId,
        plan_type: planId,
        created_via: 'FertiVision Cloud SaaS'
      }
    });
    
    return subscription;
  } catch (error) {
    console.error('Error creating subscription:', error);
    throw error;
  }
}

// Cancel subscription
export async function cancelSubscription(subscriptionId: string, cancelAtCycleEnd: boolean = true) {
  try {
    const razorpay = getRazorpayInstance();
    
    const subscription = await razorpay.subscriptions.cancel(subscriptionId, {
      cancel_at_cycle_end: cancelAtCycleEnd ? 1 : 0
    });
    
    return subscription;
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    throw error;
  }
}

// Pause subscription
export async function pauseSubscription(subscriptionId: string, pauseAt?: number) {
  try {
    const razorpay = getRazorpayInstance();
    
    const subscription = await razorpay.subscriptions.pause(subscriptionId, {
      pause_at: pauseAt || Math.floor(Date.now() / 1000)
    });
    
    return subscription;
  } catch (error) {
    console.error('Error pausing subscription:', error);
    throw error;
  }
}

// Resume subscription
export async function resumeSubscription(subscriptionId: string, resumeAt?: number) {
  try {
    const razorpay = getRazorpayInstance();
    
    const subscription = await razorpay.subscriptions.resume(subscriptionId, {
      resume_at: resumeAt || Math.floor(Date.now() / 1000)
    });
    
    return subscription;
  } catch (error) {
    console.error('Error resuming subscription:', error);
    throw error;
  }
}

// Get subscription details
export async function getSubscription(subscriptionId: string) {
  try {
    const razorpay = getRazorpayInstance();
    const subscription = await razorpay.subscriptions.fetch(subscriptionId);
    return subscription;
  } catch (error) {
    console.error('Error fetching subscription:', error);
    throw error;
  }
}

// Verify webhook signature
export function verifyWebhookSignature(
  payload: string,
  signature: string,
  secret?: string
): boolean {
  try {
    const webhookSecret = secret || process.env.RAZORPAY_WEBHOOK_SECRET;
    if (!webhookSecret) {
      console.error('Razorpay webhook secret not configured');
      return false;
    }
    
    const expectedSignature = crypto
      .createHmac('sha256', webhookSecret)
      .update(payload)
      .digest('hex');
    
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  } catch (error) {
    console.error('Error verifying webhook signature:', error);
    return false;
  }
}

// Create payment link for one-time payments
export async function createPaymentLink(
  amount: number,
  currency: string = 'INR',
  description: string,
  customerEmail?: string,
  customerName?: string
) {
  try {
    const razorpay = getRazorpayInstance();
    
    const paymentLink = await razorpay.paymentLink.create({
      amount: amount * 100, // Convert to paise
      currency,
      description,
      customer: {
        email: customerEmail,
        name: customerName
      },
      notify: {
        sms: true,
        email: true
      },
      reminder_enable: true,
      notes: {
        created_via: 'FertiVision Cloud SaaS',
        created_at: new Date().toISOString()
      }
    });
    
    return paymentLink;
  } catch (error) {
    console.error('Error creating payment link:', error);
    throw error;
  }
}

// Get payment details
export async function getPayment(paymentId: string) {
  try {
    const razorpay = getRazorpayInstance();
    const payment = await razorpay.payments.fetch(paymentId);
    return payment;
  } catch (error) {
    console.error('Error fetching payment:', error);
    throw error;
  }
}

// Create refund
export async function createRefund(paymentId: string, amount?: number, notes?: any) {
  try {
    const razorpay = getRazorpayInstance();
    
    const refund = await razorpay.payments.refund(paymentId, {
      amount: amount ? amount * 100 : undefined, // Convert to paise if specified
      notes: {
        ...notes,
        refunded_via: 'FertiVision Cloud SaaS',
        refunded_at: new Date().toISOString()
      }
    });
    
    return refund;
  } catch (error) {
    console.error('Error creating refund:', error);
    throw error;
  }
}

// Generate checkout options for frontend
export function generateCheckoutOptions(
  subscriptionId: string,
  planName: string,
  customerEmail?: string,
  customerName?: string
) {
  return {
    subscription_id: subscriptionId,
    name: 'FertiVision',
    description: `${planName} Plan Subscription`,
    image: '/logo.png', // Add your logo
    handler: function(response: any) {
      // This will be handled by frontend
      console.log('Payment successful:', response);
    },
    prefill: {
      email: customerEmail,
      name: customerName
    },
    notes: {
      plan_name: planName,
      subscribed_via: 'FertiVision Cloud SaaS'
    },
    theme: {
      color: '#4F46E5' // Indigo color matching your theme
    },
    modal: {
      ondismiss: function() {
        console.log('Payment modal dismissed');
      }
    }
  };
}

// Webhook event handlers
export const webhookHandlers = {
  'subscription.activated': async (data: any) => {
    console.log('Subscription activated:', data.payload.subscription.entity);
    // Update user subscription status in database
    return { success: true };
  },
  
  'subscription.charged': async (data: any) => {
    console.log('Subscription charged:', data.payload.payment.entity);
    // Log payment and extend subscription period
    return { success: true };
  },
  
  'subscription.cancelled': async (data: any) => {
    console.log('Subscription cancelled:', data.payload.subscription.entity);
    // Update user subscription status to cancelled
    return { success: true };
  },
  
  'subscription.paused': async (data: any) => {
    console.log('Subscription paused:', data.payload.subscription.entity);
    // Update user subscription status to paused
    return { success: true };
  },
  
  'subscription.resumed': async (data: any) => {
    console.log('Subscription resumed:', data.payload.subscription.entity);
    // Update user subscription status to active
    return { success: true };
  },
  
  'payment.failed': async (data: any) => {
    console.log('Payment failed:', data.payload.payment.entity);
    // Handle failed payment, send notification
    return { success: true };
  }
};

// Utility function to format currency
export function formatCurrency(amount: number, currency: string = 'INR'): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount / 100); // Convert from paise to rupees
}

// Get plan by ID
export function getPlanById(planId: string) {
  return SUBSCRIPTION_PLANS[planId as keyof typeof SUBSCRIPTION_PLANS] || null;
}

// Check if user can perform analysis based on subscription
export function canPerformAnalysis(
  subscriptionPlan: string,
  analysesUsed: number,
  analysesLimit: number
): boolean {
  if (subscriptionPlan === 'enterprise') {
    return true; // Unlimited for enterprise
  }
  
  return analysesUsed < analysesLimit;
}

// Calculate days until subscription renewal
export function getDaysUntilRenewal(currentPeriodEnd: number): number {
  const now = Math.floor(Date.now() / 1000);
  const daysLeft = Math.ceil((currentPeriodEnd - now) / (24 * 60 * 60));
  return Math.max(0, daysLeft);
}
